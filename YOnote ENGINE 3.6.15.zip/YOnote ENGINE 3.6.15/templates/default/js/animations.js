function jq(){
$('#topbar ul li').css({opacity:0.6});
$('#topbar ul li').hover(function(){
    $(this).animate({opacity:1.0},500);
},function (){
    $(this).animate({opacity:0.6},500);
});

$('#menu li').hover(function(){
    $('#menu li ul').css({opacity:'0.0'});
	$('#menu li ul').animate({opacity:'1.0'},150);
},function(){
$('#menu li ul').css({opacity:'0.0'});
});

$('#info_buts a').hover(function(){
    $(this).animate({opacity:0.8},500);
},function(){
    $(this).animate({opacity:1.0},500);
});
}

function comment_WYSIWYG_edit(){	
	document.getElementById("old_comment").innerHTML = '<p>'+document.getElementById('addcomm_field').value;
}