<?php
header("Content-Type: text/html; charset=cp1251");
session_start();
define(YONOTE_ENGINE,true);
require_once('config.php');
## loadmaintags();
$main_tags = array(
  "{_CONTENT_}" => returnpage(),
  "{_TITLE_}" => $page_title,
  "{_KEYWORDS_}" => $config['keywords'],
  "{_DESCRIPTION_}" => $config['description'],
  "{_AJAX_}" => "",
  "{_LOADBAR_}" => ajax_loadbar(),
  "{_TEMPLATE_}" => TPL_SET
);


// Control the pageturner to avoid showing it everywhere
allow_pageturner($main_tags);

// Load page
$noborder_template->editpath(TEMPLATE.'/main.tpl');
$noborder_template->add_tags($main_tags);
echo $noborder_template->templateset();

$db->close(); // Close mysql connection

?>