<?php
session_start();
define(YONOTE_ENGINE,true);
require_once('config.php');

if (is_logged() == TRUE){
    $nobordertmpl->editpath('template/main.tpl');
	$nobordertmpl->settags(array("{_CONTENT_}"=>content()));
    echo $nobordertmpl->templateset();
} else {
    if (!@$_POST['submit']){
        echo $template->login();
	} else {
	    $login->send_request();
	}
}

$db->close(); // Close mysql connection
?>