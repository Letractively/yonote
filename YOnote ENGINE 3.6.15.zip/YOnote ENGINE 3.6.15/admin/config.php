<?php
if (!defined("YONOTE_ENGINE")){
    die( 'Hacking attemp!' );
}

// Preload functions, that shouldn't be loaded
require_once("functions/loadlangs.func.unload.php");
require_once("functions/loadclasses.func.unload.php");
require_once("functions/loadfuncs.func.unload.php");

require_once("../engine/classes/db.class.php"); // Load ENGINE mysql class
require_once("../engine/classes/core.class.php"); // Load core class
require_once("../engine/classes/validate.class.php"); // Load core class
require_once("../engine/functions/mysql.func.php"); // Load mysql data

load_user_lang(); // Load user language
load_mysql_def(); // Load mysql data

$db=new db;
$db->connect();    // Connect to MySQL database

load_functions(); // Load admin  functions

loadcfg();        // Load ENGINE conf

define(PAGE,$_GET['page'],TRUE);
define(CURRENT,'3615',TRUE);
define(LINK_MOD,'index.php?page=mods&act=modset&modname='.$_GET['modname'],TRUE);

$template = new template;
$login = new login;
$nobordertmpl = new nobordertmpl;
$news = new news;
$newsadd = new newsadd;
$validate = new validate;
$newstools = new newstools;
$addcat = new addcat;
$cattools = new cattools;
$usertools = new usertools;
$comments = new comments;
$update = new update;
$pages = new pages;
$settings = new settings;
$mods = new mods;
$uploads = new uploads;

loadmodules();
?>