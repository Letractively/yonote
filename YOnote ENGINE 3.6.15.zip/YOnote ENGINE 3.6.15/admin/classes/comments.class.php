<?php
class comments
{

    public function onshow(){
	    ## do it
	}
	
	public function onaccept(){
	    ## do it
	}
	
	public function onreject(){
	    ## do it
	}
	
    public function showlist(){
	GLOBAL $lang,$lang_err;  
		$query = db::query("SELECT * FROM ".PREFIX."_comments WHERE comment_verif='0'",false);
		$num = @mysql_num_rows($query);
		if ($num < 1){
		    return $lang_err['comments_no_to_moder'];
		} else {
		    $nobordertmpl = new nobordertmpl;
		    $nobordertmpl->editpath('template/commentslist.tpl');
			while ($row = @mysql_fetch_array($query)){
			    $nobordertmpl->settags(array(
				  "{_ID_}" => $row['id'],
				  "{_POSTDATE_}" => date("d.m.Y",$row['comment_date']),
				  "{_COMMENT_}" => $row['comment_content'],
				  "{_AUTHORID_}" => $row['comment_author_id'],
				  "{_AUTHOR_}" => $row['comment_author']
				));
				$return .= $nobordertmpl->templateset();
			}
			$this->onshow();
			return $return;
		}
	}
	
	public function accept($id){
	GLOBAL $lang,$lang_err;
	    $query = db::query("SELECT * FROM ".PREFIX."_comments WHERE comment_verif='0' AND id='".core::clrtxt($id)."'",false);
		$num = @mysql_num_rows($query);
		if ($num < 1){
		    return $lang_err['comment_no_such_found'];
		} else {
		    db::query("UPDATE ".PREFIX."_comments SET comment_verif='1' WHERE id='".core::clrtxt($id)."'",true);
			$this->onaccept();
			return $lang['comments_accept_succ'];
		}
	}
	
	public function reject($id){
	GLOBAL $lang,$lang_err;
	    $query = db::query("SELECT * FROM ".PREFIX."_comments WHERE comment_verif='0' AND id='".core::clrtxt($id)."'",false);
		$num = @mysql_num_rows($query);
		if ($num < 1){
		    return $lang_err['comment_no_such_found'];
		} else {
		    db::query("DELETE FROM ".PREFIX."_comments WHERE id='".core::clrtxt($id)."'",true);
			$this->onreject();
			return $lang['comments_reject_succ'];
		}
	}
}
?>