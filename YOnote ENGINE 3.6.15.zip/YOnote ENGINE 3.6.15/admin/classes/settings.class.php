<?php
class settings
{

    public function onupdate(){
	    ## do it
	}
	
    public function main(){
	    $nobordertmpl = new nobordertmpl;
		$nobordertmpl->editpath('template/setactions.tpl');
		$nobordertmpl->settags(array("" => ""));
		return $nobordertmpl->templateset();
	}

	public function preferences(){
	GLOBAL $config;
	    $nobordertmpl = new nobordertmpl;
		$nobordertmpl->editpath('template/preferences.tpl');
		$nobordertmpl->settags(array(
		  "{_KEYWORDS_}" => $config['keywords'],
		  "{_DESCRIPTION_}" => $config['description'],
		  "{_SITENAME_}" => $config['site_name']
		));
		return $nobordertmpl->templateset();
	}
	
	public function prefupdate(){
	GLOBAL $lang_err,$validate,$lang;
	    if (!$validate->standart($_POST['keywords'],3,250,"!^.+$!")){
		    return $lang_err['set_keywords_invalid'];
		} elseif (!$validate->standart($_POST['description'],3,200,"!^.+$!")){
		    return $lang_err['set_description_invalid'];
		} elseif (!$validate->standart($_POST['sitename'],3,100,"!^.+$!")){
		    return $lang_err['set_sitename_invalid'];
		} else {
		    db::query("UPDATE ".PREFIX."_config SET 
              keywords='".core::clrtxt($_POST['keywords'])."',
			  description='".core::clrtxt($_POST['description'])."',
			  site_name='".core::clrtxt($_POST['sitename'])."' 
			WHERE id='1'",true);
			$this->onupdate();
			return $lang['set_info_upd'];
		}
	}
	
	public function pubdeforms(){
	GLOBAL $config;
	    $nobordertmpl = new nobordertmpl;
		$nobordertmpl->editpath('template/setpublic.tpl');
		
		if ($config['sort_news_by'] == 'id'){
		    $selected_1 = "selected";
			$selected_2 = NULL;
		} elseif ($config['sort_news_by'] == 'news_post_date'){
		    $selected_1 = NULL;
			$selected_2 = "selected";
		}
		
		if ($config['sort_type'] == 'ascending'){
		    $selected_3 = "selected";
			$selected_4 = NULL;
		} elseif ($config['sort_type'] == 'descending'){
		    $selected_3 = NULL;
			$selected_4 = "selected";
		}
		
		if ($config['sort_comments_by'] == 'id'){
		    $selected_5 = "selected";
			$selected_6 = NULL;
		} elseif ($config['sort_comments_by'] == 'comment_date'){
		    $selected_5 = NULL;
			$selected_6 = "selected";
		}
		
		if ($config['comments_sort_type'] == 'ascending'){
		    $selected_7 = "selected";
			$selected_8 = NULL;
		} elseif ($config['comments_sort_type'] == 'descending'){
		    $selected_7 = NULL;
			$selected_8 = "selected";
		}
		
		if ($config['news_cat_sort_type'] == 'ascending'){
		    $selected_11 = "selected";
			$selected_12 = NULL;
		} elseif ($config['news_cat_sort_type'] == 'descending'){
		    $selected_11 = NULL;
			$selected_12 = "selected";
		}
		
		if ($config['news_cat_sort_by'] == 'id'){
		    $selected_9 = "selected";
			$selected_10 = NULL;
		} elseif ($config['news_cat_sort_by'] == 'cat_name'){
		    $selected_10 = "selected";
			$selected_9 = NULL;
		}
		
		if ($config['unreg_can_add_comm'] == '1'){
		    $checked_1 = "checked";
		}
		if ($config['comments_shoud_moderate'] == '1'){
		    $checked_2 = "checked";
		}
		if ($config['allow_news_unreg_default'] == '1'){
		    $checked_3 = "checked";
		}
		if ($config['allow_news_comments_default'] == '1'){
		    $checked_4 = "checked";
		}
		if ($config['news_need_verification'] == '1'){
		    $checked_5 = "checked";
		}
		
		$nobordertmpl->settags(array(
		  "{_SELECTED_1_}" => $selected_1,
		  "{_SELECTED_2_}" => $selected_2,
		  "{_SELECTED_3_}" => $selected_3,
		  "{_SELECTED_4_}" => $selected_4,
		  "{_SELECTED_5_}" => $selected_5,
		  "{_SELECTED_6_}" => $selected_6,
		  "{_SELECTED_7_}" => $selected_7,
		  "{_SELECTED_8_}" => $selected_8,
		  "{_SELECTED_9_}" => $selected_9,
		  "{_SELECTED_10_}" => $selected_10,
		  "{_SELECTED_11_}" => $selected_11,
		  "{_SELECTED_12_}" => $selected_12,
		  "{_NEWSPERPAGE_}" => $config['news_on_page'],
		  "{_LASTNEWSPERPAGE_}" => $config['last_news_on_page'],
		  "{_CHECKED_1_}" => $checked_1,
		  "{_CHECKED_2_}" => $checked_2,
		  "{_CHECKED_3_}" => $checked_3,
		  "{_CHECKED_4_}" => $checked_4,
		  "{_CHECKED_5_}" => $checked_5,
		  "{_COMMENTSONNEWS_}" => $config['comm_on_news']
		));
		return $nobordertmpl->templateset();
	}
	
	public function publicupdate(){
	GLOBAL $lang,$validate,$lang_err;
	    if (!preg_match("!^[0-9]+$!",$_POST['newsperpage']) || $_POST['newsperpage'] > 100 || $_POST['newsperpage'] < 1){
		    return $lang_err['set_newsperpage_invalid'];
		} elseif (!preg_match("!^[0-9]+$!",$_POST['lastnewsperpage']) || $_POST['lastnewsperpage'] > 100 || $_POST['lastnewsperpage'] < 1){
		    return $lang_err['set_lastnewsperpage_invalid'];
		} elseif (!preg_match("!^[0-9]+$!",$_POST['comm_on_news']) || $_POST['comm_on_news'] > 100 || $_POST['comm_on_news'] < 1){
		    return $lang_err['set_lastcomm_invalid'];
		} else {
		
		    $allow_news_unreg_default="0";
			$allow_news_comments_default="0";
			$news_need_verification="0";
			$unreg_can_add_comm="0";
			$comments_shoud_moderate="0";
			
		    if (@$_POST['allow_news_unreg_default']){
			    $allow_news_unreg_default = "1";
			}
			if (@$_POST['allow_news_comments_default']){
			    $allow_news_comments_default = "1";
			}
			if (@$_POST['news_need_verification']){
			    $news_need_verification = "1";
			}
			if (@$_POST['unreg_can_add_comm']){
			    $unreg_can_add_comm = "1";
			}
			if (@$_POST['comments_shoud_moderate']){
			    $comments_shoud_moderate = "1";
			}
			
			db::query("UPDATE ".PREFIX."_config SET 
			    sort_news_by='".core::clrtxt($_POST['newssortby'])."',
				sort_type='".core::clrtxt($_POST['newssort_type'])."',
				news_on_page='".core::clrtxt($_POST['newsperpage'])."',
				last_news_on_page='".core::clrtxt($_POST['lastnewsperpage'])."',
				allow_news_unreg_default='$allow_news_unreg_default',
				allow_news_comments_default='$allow_news_comments_default',
				news_need_verification='$news_need_verification',				
				unreg_can_add_comm='$unreg_can_add_comm',
				comments_shoud_moderate='$comments_shoud_moderate',
				comm_on_news='".core::clrtxt($_POST['comm_on_news'])."',
				sort_comments_by='".core::clrtxt($_POST['sort_comments_by'])."',
				comments_sort_type='".core::clrtxt($_POST['comments_sort_type'])."',
				news_cat_sort_by='".core::clrtxt($_POST['news_cat_sort_by'])."',
				news_cat_sort_type='".core::clrtxt($_POST['news_cat_sort_type'])."'
			 WHERE id='1' ",true);
			$this->onupdate();
			return $lang['set_info_upd'];
		
		
		}
	}
	
	private function defaultreggroup(){
	GLOBAL $config;
	    $query = db::query("SELECT * FROM ".PREFIX."_usergroup",true);
		while ($row = @mysql_fetch_array($query)){
		    if ($config['standart_usergroup'] == $row['category_name']){
			    $return .= "<option value='{$row['category_name']}' selected>{$row['category_description']}</option>";
			} else {
		        $return .= "<option value='{$row['category_name']}'>{$row['category_description']}</option>";
			}
		}
		return $return;
	}
	
	public function userpref(){
	GLOBAL $config;
	    $nobordertmpl = new nobordertmpl;
		$nobordertmpl->editpath('template/userpref.tpl');
		
		$require_email_validation=NULL;
		$need_account_activation=NULL;
		
		if ($config['require_email_validation'] == "1"){
		    $checked_1 = "checked";
		}
		if ($config['need_account_activation'] == "1"){
		    $checked_2 = "checked";
		}
		
		$nobordertmpl->settags(array(
		  "{_NEWUSERCAT_}" => $this->defaultreggroup(),
		  "{_CHECKED_1_}" => $checked_1,
		  "{_CHECKED_2_}" => $checked_2,
		  "{_PHOTOMAX_W_}" => $config['userphoto_max_w'],
		  "{_PHOTOMAX_H_}" => $config['userphoto_max_h'],
		  "{_PHOTOMAX_BYTES_}" => $config['userphoto_max_size']
		));
		return $nobordertmpl->templateset();
	}
	
	public function updateuserpref(){
	GLOBAL $validate,$lang,$lang_err;
	    if (!$validate->standart($_POST['userphoto_max_w'],2,4,"!^[1-9]+[0-9]*$!")){
		    return $lang_err['set_photomaxwh_invalid'];
		} elseif (!$validate->standart($_POST['userphoto_max_h'],2,4,"!^[1-9]+[0-9]*$!")){
		    return $lang_err['set_photomaxwh_invalid'];
		} elseif (!preg_match("!^[1-9]+[0-9]*$!",$_POST['userphoto_max_size'])){
		    return $lang_err['set_photobytes_invalid'];
		} else {
		
		    $require_email_validation = "0";
			$need_account_activation = "0";
		    if (@$_POST['require_email_validation']){
			    $require_email_validation = "1";
			}
			if (@$_POST['need_account_activation']){
			    $need_account_activation = "1";
			}
		
		    db::query("UPDATE ".PREFIX."_config SET 
			  require_email_validation='$require_email_validation',
			  need_account_activation='$need_account_activation',
			  standart_usergroup='".core::clrtxt($_POST['new_user_cat'])."',
			  userphoto_max_w='".core::clrtxt($_POST['userphoto_max_w'])."',
			  userphoto_max_h='".core::clrtxt($_POST['userphoto_max_h'])."',
			  userphoto_max_size='".core::clrtxt($_POST['userphoto_max_size'])."'
			 WHERE id='1'",true);
			 $this->onupdate();
			return $lang['set_info_upd'];
		}
	}
	
	public function systempref(){
	GLOBAL $config;
	    $nobordertmpl = new nobordertmpl;
		$nobordertmpl->editpath('template/systempref.tpl');
		
		
		if ($config['show_on_main'] == '0'){
		    $selected_1 = "selected";
			$selected_2 = NULL;
			$selected_3 = NULL;
			$selected_4 = NULL;
			$selected_5 = NULL;
		} elseif ($config['show_on_main'] == '1'){
		    $selected_1 = NULL;
			$selected_2 = "selected";
			$selected_3 = NULL;
			$selected_4 = NULL;
			$selected_5 = NULL;
		} elseif ($config['show_on_main'] == '2'){
		    $selected_1 = NULL;
			$selected_2 = NULL;
			$selected_3 = "selected";
			$selected_4 = NULL;
			$selected_5 = NULL;
		} elseif ($config['show_on_main'] == '3'){
		    $selected_1 = NULL;
			$selected_2 = NULL;
			$selected_3 = NULL;
			$selected_4 = "selected";
			$selected_5 = NULL;
		} elseif ($config['show_on_main'] == '4'){
		    $selected_1 = NULL;
			$selected_2 = NULL;
			$selected_3 = NULL;
			$selected_4 = NULL;
			$selected_5 = "selected";
		}
		
		if ($config['allow_ajax'] == '1'){
		    $checked_1 = "checked";
		} else {
		    $checked_1 = NULL;
		}
		
		$nobordertmpl->settags(array(
		  "{_TEMPLATES_}" => $this->templatelist(),
		  "{_SELECTED_1_}" => $selected_1,
		  "{_SELECTED_2_}" => $selected_2,
		  "{_SELECTED_3_}" => $selected_3,
		  "{_SELECTED_4_}" => $selected_4,
		  "{_SELECTED_5_}" => $selected_5,
		  "{_PAGES_}" => $this->custompagelist(),
		  "{_CUSTOMTPLTAG_}" => $config['custom_tpl_tag'],
		  "{_CHECKED_1_}" => $checked_1
		  
		));
		return $nobordertmpl->templateset();
	}
	
	public function updsyspref(){
	GLOBAL $lang,$lang_err;
	
	$allow_ajax = "0";
	if (@$_POST['allow_ajax']){
	    $allow_ajax = "1";
	}
	    db::query("UPDATE ".PREFIX."_config SET 
		  site_template='".core::clrtxt($_POST['site_template'])."',
		  show_on_main='".core::clrtxt($_POST['show_on_main'])."',
		  custom_pagename='".core::clrtxt($_POST['custom_pagename'])."',
		  custom_tpl_tag='".core::clrtxt($_POST['custom_tpl_tag'])."',
		  allow_ajax='$allow_ajax'
		WHERE id='1'",true);
		$this->onupdate();
		return $lang['set_info_upd'];
	}
	
	public function templatelist(){
	GLOBAL $config;
	    $scan = scandir('../templates');
		for ($i=2;$i < count($scan);$i++){
		    if ($config['site_template'] == $scan[$i]){
			    $return .= "<option name='template' selected value='{$scan[$i]}'>".$scan[$i].'</option>';
			} else {
		        $return .= "<option name='template' value='{$scan[$i]}'>".$scan[$i].'</option>';
			}
		}
		return $return;
	}
	
	private function custompagelist(){
	GLOBAL $config;
	    $query = db::query("SELECT * FROM ".PREFIX."_pages",true);
		while ($row = @mysql_fetch_array($query)){
		    if ($config['custom_pagename'] == $row['page_name']){
		        $return .= "<option value='{$row['page_name']}' selected>{$row['page_title']}</option>";
			} else {
			    $return .= "<option value='{$row['page_name']}'>{$row['page_title']}</option>";
			}
		}
		return $return;
	}
}
?>