<?php
class template
{
  public static $template_tags=array();
  public $template_path;
  public $tag;
  public $return_tmpl;
  
  public function templateset(){
     $template = file_get_contents($this->template_path);
	 $tags = $this->template_tags;
	 $tags_reversed = array_reverse($tags,TRUE);
	 $tag = $this->tag;
	 $mask = "!\{$tag\}(.*?)\{/$tag\}!sei";
	 preg_match ("$mask", $template, $matches);
	 $uncomp_templ = $matches[1];
	 $count=0;
	 foreach ($tags as $row => $value){
	 $count++;
	   if ($count == 1){
	     $template_return = str_replace($row, $value, $uncomp_templ);
	   } else {
	     $template_return = str_replace($row, $value, $template_return);
	   }
	 }	 
	 $template_return = str_replace('{'.$tag.'}', '', str_replace('{/'.$tag.'}', '', $template_return));
	 return $template_return;
  }
  
  public function settags($tags){
      $this->template_tags = $tags;
  }
  
  public function editpath($path){
      $this->template_path = $path;
  }
  
  public function setbordertag($tag){
      $this->tag = $tag;
  }
  
  public function add_tags($addition){
      if ($this->template_tags != NULL){
          $this->template_tags = $this->template_tags + $addition;
	  } else {
	      $this->template_tags = $addition;
	  }
  }

    public function login(){
	    $template='template/login.tpl';
		$template=file_get_contents($template);
		return $template;
	}
}
?>