<?php
class login
{

    public function onlogin(){
	    ## do it
	}
	
	public function onlogout(){
	    ## do it
	}

    public function send_request(){
	    $query = db::query("SELECT * FROM ".PREFIX."_user WHERE user_login='".core::clrtxt($_POST['login'])."' AND user_password='".md5(core::clrtxt($_POST['password']))."' AND user_admin='1'",true);
		$num = @mysql_num_rows($query);
		if ($num == 1){
		    $row = @mysql_fetch_array($query);
			$admin_row = $row;
		    $_SESSION['mylogin'] = $admin_row['user_login'];
			$_SESSION['myid'] = $admin_row['id'];
			$_SESSION['logged'] = md5($admin_row['user_login']).md5($admin_row['id']);
			$_SESSION['mygroup'] = $admin_row['user_group'];
			$this->onlogin();
			core::redirect('index.php');
		} else {
		    $query = db::query("SELECT * FROM ".PREFIX."_user WHERE user_login='".core::clrtxt($_POST['login'])."' AND user_password='".md5(core::clrtxt($_POST['password']))."'",false);
			$row = @mysql_fetch_array($query);
			$query = db::query("SELECT * FROM ".PREFIX."_usergroup WHERE category_name='{$row['user_group']}' AND is_admin='1'",false);
			$num = @mysql_num_rows($query);
			if ($num > 0){
			    $_SESSION['mylogin'] = $row['user_login'];
			    $_SESSION['myid'] = $row['id'];
			    $_SESSION['logged'] = md5($row['user_login']).md5($row['id']);
			    $_SESSION['mygroup'] = $row['user_group'];
				$this->onlogin();
			    core::redirect('index.php');
			} else {
		        $_SESSION['admin_counter']++;
			    core::redirect('index.php');
			}
		}
	}
	
	public function logout(){
	    if (is_logged() == TRUE){
		    unset($_SESSION['mylogin']);
			unset($_SESSION['myid']);
			unset($_SESSION['logged']);
			unset($_SESSION['mygroup']);
			$this->onlogout();
			core::redirect('index.php');
		} else {
		    core::redirect('index.php');
		}
	}
}
?>