<?php
class pages
{
    public function onadd(){
	    ## do it
	}
	
	public function oninsert(){
	    ## do it
	}
	
	public function onedit(){
	    ## do it
	}
	
	public function onupdate(){
	    ## do it
	}
	
	public function onremove(){
	    ## do it
	}

    public function pageactions(){
	    $nobordertmpl = new nobordertmpl;
		$nobordertmpl->editpath('template/pageactions.tpl');
		$nobordertmpl->settags(array("" => ""));
		return $nobordertmpl->templateset();
	}
	
	public function addpage(){
	    $nobordertmpl = new nobordertmpl;
		$nobordertmpl->editpath('template/addpage.tpl');
		$nobordertmpl->settags(array("" => ""));
		$this->onadd();
		return $nobordertmpl->templateset();
	}
	
	public function submit(){
	GLOBAL $validate,$lang_err,$lang;
	
	$hidden = "0";
	if (@$_POST['hide_page']){
	    $hidden = "1";
	}
	
	    if (!$validate->standart($_POST['sysname'],3,40,"!^[a-z_]+[a-z0-9_]+$!")){
		    return $lang_err['pages_sysname_invalid'];
		} elseif (!$validate->standart($_POST['header'],3,40,"!^[a-zA-Z�-��-�_ 0-9]+$!")){
		    return $lang_err['pages_hname_invalid'];
		} else {
		    db::query("INSERT INTO ".PREFIX."_pages SET 
			  page_name='".core::clrtxt($_POST['sysname'])."',
			  page_title='".core::clrtxt($_POST['header'])."',
			  page_content='".core::clrtxt($_POST['pagecontent'])."',
			  page_hidden='$hidden'
			",true);
			return $lang['page_add_succ'];
		}
	}
	
	public function pagelist(){
	    $query = db::query("SELECT * FROM ".PREFIX."_pages",false);
		$num = @mysql_num_rows($query);
		if ($num > 0){
		    $nobordertmpl = new nobordertmpl;
			$nobordertmpl->editpath('template/pagelist.tpl');
			$counter=1;
		    while ($row = @mysql_fetch_array($query)){
			
			    if ($counter == 3){
		            $counter=1;
		        }
		
		        if ($counter == 1){
		            $style = "style='background-color:#00446f'";
		        } else {
		            $style = NULL;
		        }
				
			    $nobordertmpl->settags(array(
				  "{_ID_}" => $row['id'],
				  "{_PNAME_}" => $row['page_name'],
				  "{_PTITLE_}" => $row['page_title'],
				  "{_STYLE_}" => $style
				));
				$return .= $nobordertmpl->templateset();
				$counter++;
			}
			return $return;
		} else {
		    return FALSE;
		}
	}
	
	public function pageisset($id){
	    $query = db::query("SELECT * FROM ".PREFIX."_pages WHERE id='".core::clrtxt($id)."'",false);
		$num = @mysql_num_rows($query);
		if ($num > 0){
		    return $query;
		} else {
		    return FALSE;
		}
	}
	
	public function pagetools(){
	GLOBAL $lang_err;
	    $pagelist = $this->pagelist();
		if ($pagelist != FALSE){
	        $nobordertmpl = new nobordertmpl;
		    $nobordertmpl->editpath('template/pagetools.tpl');
		    $nobordertmpl->settags(array("{_PAGELIST_}" => $pagelist));
		    return $nobordertmpl->templateset();
		} else {
		    return $lang_err['pages_nopages_toshow'];
		}
	}
	
	public function edit(){
	GLOBAL $lang_err;
	$pageisset = $this->pageisset($_GET['id']);
	    if ($pageisset != FALSE){
		    $nobordertmpl = new nobordertmpl;
		    $nobordertmpl->editpath('template/editpage.tpl');
			$row = @mysql_fetch_array($pageisset);
			$checked=NULL;
			if ($row['page_hidden'] == "1"){
			    $checked="checked";
			}
		    $nobordertmpl->settags(array(
			  "{_SYSNAME_}" => $row['page_name'],
			  "{_DESC_}" => $row['page_title'],
			  "{_CONTENT_}" => $row['page_content'],
			  "{_CHECKED_}" => $checked
			));
		    return $nobordertmpl->templateset();
		} else {
		    return $lang_err['pages_no_suchone'];
		}
	}
	
	public function update(){
	GLOBAL $lang,$lang_err,$validate;
	
	$hidden = "0";
	if (@$_POST['hide_page']){
	    $hidden = "1";
	}
        if (!$validate->standart($_POST['sysname'],3,40,"!^[a-z_]+[a-z0-9_]+$!")){
		    return $lang_err['pages_sysname_invalid'];
		} elseif (!$validate->standart($_POST['header'],3,40,"!^[a-zA-Z�-��-�_ 0-9]+$!")){
		    return $lang_err['pages_hname_invalid'];
		} else {
		    db::query("UPDATE ".PREFIX."_pages SET 
			  page_name='".core::clrtxt($_POST['sysname'])."',
			  page_title='".core::clrtxt($_POST['header'])."',
			  page_content='".mysql_real_escape_string($_POST['pagecontent'])."',
			  page_hidden='$hidden'
			 WHERE id='".core::clrtxt($_GET['id'])."'",true);
			$this->onupdate();
			return $lang['page_upd_succ'];
		}
	}
	
	public function delete(){
	GLOBAL $lang,$lang_err;
	$query = db::query("SELECT * FROM ".PREFIX."_pages",false);
	$counter=0;
	while ($row = @mysql_fetch_array($query)){
	    if (@$_POST['del_'.$row['id']]){
		    $counter++;
			db::query("DELETE FROM ".PREFIX."_pages WHERE id='{$row['id']}'",false);
		}
	}
	if ($counter > 0){
	    $this->onremove();
	    return $lang['page_delete_succ'];
	} else {
	    return $lang_err['pages_no_act_done'];
	}
	}
}
?>