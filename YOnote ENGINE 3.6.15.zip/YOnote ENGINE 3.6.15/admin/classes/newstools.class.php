<?php
class newstools extends newsadd
{
	
	// On news list form
	public function onnewslist(){
	    ## do it
	}
	
	// On search results
	public function onsearch(){
	    ## do it
	}
	
	// On edit forms show
	public function onedit(){
	    ## do it
	}
	
	// On news update
	public function onupdate(){
	    ## do it
	}
	
	public function onremove(){
	    ## do it
	}
	

    public function showtools(){
	GLOBAL $lang_err;
	$num=0;
	$query = db::query("SELECT * FROM ".PREFIX."_news",true);
	while ($row_num_ver = @mysql_fetch_array($query)){
	    if ($row_num_ver['verified'] == '0'){
		    $num++;
		}
	}
	$num_all_news = @mysql_num_rows($query);
	if ($num_all_news > 0){
	
	$query_cats = db::query("SELECT * FROM ".PREFIX."_news_cats",true);
	while ($row_cats = @mysql_fetch_array($query_cats)){
	    $cat_list .= "<option value='{$row_cats['id']}'>{$row_cats['cat_desc']}</option>";
	}
	    $nobordertmpl = new nobordertmpl;
	    $nobordertmpl->editpath('template/newstools.tpl');
		$nobordertmpl->settags(array("{_NEWSLIST_}"=>$this->newslist(null,null), "{_MODERNEWS_}" => "$num", "{_CATS_}" => $cat_list));
	
	return $nobordertmpl->templateset();	    
	} else {
	    return $lang_err['no_news_to_show'];
	}
	}
	
	public function newslist($type,$qr){
	GLOBAL $lang;
	    $nobordertmpl = new nobordertmpl;
		$nobordertmpl->editpath('template/newslist.tpl');
		if ($type == NULL){
		    $query = db::query("SELECT * FROM ".PREFIX."_news ORDER BY id DESC",true);
		} else {
		    $query = db::query("SELECT * FROM ".PREFIX."_news $qr ORDER BY id DESC",true);
		}
		$counter=1;
		$num = @mysql_num_rows($query);
		while ($row = mysql_fetch_array($query)){
		
		if ($counter == 3){
		    $counter=1;
		}
		
		if ($counter == 1){
		    $style = "style='background-color:#00446f'";
		} else {
		    $style = NULL;
		}
		
		if ($row['verified'] == "0"){
		    $verified = $lang['no'];
		} elseif ($row['verified'] == "1") {
		    $verified = $lang['yes'];
		}
		    $nobordertmpl->settags(array("{_STYLE_}" => $style,"{_ID_}"=>$row['id'],"{_TITLE_}" => $row['news_title'],"{_DATE_}" => date("d.m.Y",$row['news_post_date']), "{_AUTHOR_}" => $row['news_author'], "{_VERIFIED_}" => $verified ));
			$result .= $nobordertmpl->templateset();
		$counter++;
		}
		
		if ($num != 0){
		    $this->onnewslist();
		    return $result;
		} else {
		    return FALSE;
		}
	}
	
	public function findnews(){
	GLOBAL $lang_err;
	    if(@$_POST['submit'] || $_REQUEST['search'] == 'custom'){
		    switch($_REQUEST['stype']){
			    case 'by_id':$qr="WHERE id=".core::clrtxt($_REQUEST['searchbox'])."";
				break;
				
				case 'by_title':$qr="WHERE news_title LIKE '%".core::clrtxt($_REQUEST['searchbox'])."%'";
				break;
				
				case 'by_short':$qr="WHERE news_short LIKE '%".core::clrtxt($_REQUEST['searchbox'])."%'";
				break;
				
				case 'by_full':$qr="WHERE news_full LIKE '%".core::clrtxt($_REQUEST['searchbox'])."%'";
				break;
				
				case 'by_cat':$qr="WHERE news_category LIKE '%".core::clrtxt($_REQUEST['searchbox'])."%'";
				break;
				
				case 'by_cat_id':$qr="WHERE news_category_id='".core::clrtxt($_REQUEST['searchbox'])."'";
				break;
			}
			
			if ((core::clrtxt($_REQUEST['searchbox']) == NULL) || ($_REQUEST['stype'] == 'by_id' && !preg_match("![0-9]!",$_REQUEST['searchbox']))){
			    return $lang_err['searchbox_empty'];
			} else {
			    $query = db::query("SELECT * FROM ".PREFIX."_news $qr",false);
				$num = @mysql_num_rows($query);
				if ($num == 0){
				    return $lang_err['search_no_result'];
				} else {
				    $query_cats = db::query("SELECT * FROM ".PREFIX."_news_cats",true);
	                while ($row_cats = @mysql_fetch_array($query_cats)){
	                    $cat_list .= "<option value='{$row_cats['id']}'>{$row_cats['cat_desc']}</option>";
	                }
				    $nobordertmpl = new nobordertmpl;
	                $nobordertmpl->editpath('template/newssearchresults.tpl');
					$nobordertmpl->settags(array("{_RESULTS_}" => $this->newslist('search',$qr), "{_CATS_}" => $cat_list));
				    $this->onsearch();
					return $nobordertmpl->templateset();
				}
			}
		} else {
		    core::redirect('index.php?page=news');
		}
	}
	
	public function newsoptions(){
	GLOBAL $lang,$lang_err;		
	    $count=0;
		$query = db::query("SELECT * FROM ".PREFIX."_news",true);
		if ($_POST['options'] == 'del'){ // If option is "delete"
		  while ($row = @mysql_fetch_array($query)){
		    if (@$_POST['check_'.$row['id']]){
			        $count++;
			        db::query("DELETE FROM ".PREFIX."_news WHERE id='{$row['id']}'",true);
			}
		  }
		  if ($count > 0){
		      $this->onremove();
		      return $lang['news_selected_deleted'];
		  } else {
		      return $lang_err['news_act_nothing'];
		  }
		} elseif ($_POST['options'] == 'markasproven'){ // If option is "mark as proven"
		    while ($row = @mysql_fetch_array($query)){
		    if (@$_POST['check_'.$row['id']]){
			        $count++;
			        db::query("UPDATE ".PREFIX."_news SET verified='1',news_hidden='0' WHERE id='{$row['id']}'",true);
			}
		  }
		  if ($count > 0){
		      return $lang['news_selected_verified'];
		  } else {
		      return $lang_err['news_act_nothing'];
		  }
		} elseif ($_POST['options'] == 'move'){ // If option is "move to..."
		    while ($row = @mysql_fetch_array($query)){
		    if (@$_POST['check_'.$row['id']]){
			        $count++;
					$query_cats = db::query("SELECT cat_desc FROM ".PREFIX."_news_cats WHERE id='".$_POST['newcat']."'",true);
					$row_cats = @mysql_fetch_array($query_cats);
			        db::query("UPDATE ".PREFIX."_news SET news_category_id='".core::clrtxt($_POST['newcat'])."', news_category='{$row_cats['cat_desc']}' WHERE id='{$row['id']}'",true);
			}
		  }
		  if ($count > 0){
		      return $lang['news_selected_moved'];
		  } else {
		      return $lang_err['news_act_nothing'];
		  }
		}

	}
	
	public function newsisset($id){
	    $num=0;
	    $query = db::query("SELECT * FROM ".PREFIX."_news WHERE id='".core::clrtxt($id)."'",false);
		$num = @mysql_num_rows($query);
		if ($num == 1){
		    return $query;
		} else {
		    return FALSE;
		}
	}
	
	public function catlisttoedit($current){
	    $query = db::query("SELECT * FROM ".PREFIX."_news_cats",true);
		while ($row = @mysql_fetch_array($query)){
		    if ($row['id'] == $current){
			    $list .= "<option selected='true' value='{$row['id']}'>{$row['cat_desc']}</option>";
			} else {
		        $list .= "<option value='{$row['id']}'>{$row['cat_desc']}</option>";
			}
		}
		
		return $list;
	}
	
	public function editnews(){
    GLOBAL $lang_err;
	    $id = $_GET['id'];
		if ($this->newsisset($id) != FALSE){
		    $row = mysql_fetch_array($this->newsisset($id));
			if ($row['news_allow_unreg'] == '0'){
			    $checked_1 = "checked";
			} else {
			    $checked_1 = NULL;
			}
			
			if ($row['news_allow_comment'] == '0'){
			    $checked_2 = "checked";
			} else {
			    $checked_2 = NULL;
			}
			
			if ($row['news_hidden'] == "1"){
			    $checked_3 = "checked";
			} else {
			    $checked_3 = NULL;
			}
			
		    $nobordertmpl = new nobordertmpl;
			$nobordertmpl->editpath('template/newsedit.tpl');
			$nobordertmpl->settags(array(
			  "{_TITLE_}"=>$row['news_title'],
			  "{_SHORT_}" => $row['news_short'],
			  "{_FULL_}" => $row['news_full'],
			  "{_CHECK_1_}" => $checked_1,
			  "{_CHECK_2_}" => $checked_2,
			  "{_CHECK_3_}" => $checked_3,
			  "{_CATS_}" => $this->catlisttoedit($row['news_category_id']),
			  "{_ID_}" => $row['id']
			
			
			));
			$this->onedit();
			return $nobordertmpl->templateset();
		} else {
		    return $lang_err['news_no_such_one'];
		}
	}
	
	public function updatenews(){
	GLOBAL $lang_err,$validate,$config,$lang;
	    if ($validate->standart($_POST['news_title'],3,100,"!.?!") != TRUE){
		    return $lang_err['news_title_invalid'];
		} elseif ($validate->standart($_POST['news_short'],20,1000,"!.?!") != TRUE){
		    return $lang_err['news_short_invalid'];
		} elseif ($validate->standart($_POST['news_full'],20,5000,"!.?!") != TRUE){
		    return $lang_err['news_full_invalid'];
		} elseif ($this->truecat(null) != TRUE){
            return $lang_err['news_category_invalid'];
        } else {
		
		    if (@$_POST['allow_unreg'] == 'false'){
			    $news_allow_unreg = 0;
			} else {
			    if ($config['allow_news_unreg_default'] == '1'){
			        $news_allow_unreg = 1;
				} else {
				    $news_allow_unreg = 0;
				}
			}
			
			if (@$_POST['allow_comment'] == 'false'){
			    $news_allow_comment = 0;
			} else {
			    if ($config['allow_news_comments_default'] == '1'){
			        $news_allow_comment = 1;
				} else {
				    $news_allow_comment = 0;
				}
			}
			
			$news_hidden = "0";
			if (@$_POST['hide_news']){
			    $news_hidden = "1";
			}
			
			db::query("UPDATE ".PREFIX."_news SET 
			news_title='".core::clrtxt($_POST['news_title'])."', 
			news_short='".core::clrnfull($_POST['news_short'])."', 
			news_full='".core::clrnfull($_POST['news_full'])."', 
			news_author='".$_SESSION['mylogin']."', 
			news_author_id='".$_SESSION['myid']."',
			news_post_date='".time()."',
			news_allow_unreg='$news_allow_unreg',
			news_allow_comment='$news_allow_comment',
			news_category='".$this->truecat('catdesc')."',
			news_category_id='".$_POST['category']."',
			news_rating='0',
			verified='1',
			news_hidden = '$news_hidden'
			 WHERE id='".core::clrtxt($_GET['id'])."'
			",true);
			$this->onupdate();
			return $lang['news_edit_succ'];
			
		}
	}
	
	public function newsneedmoder(){
	GLOBAL $lang_err;
	    $newslist = $this->newslist('find',"WHERE verified='0'");
		if ($newslist != FALSE){
		    $nobordertmpl = new nobordertmpl;
	        $nobordertmpl->editpath('template/newssearchresults.tpl');
		    $nobordertmpl->settags(array("{_RESULTS_}" => $newslist));
	        return $nobordertmpl->templateset();
		} else {
		    return $lang_err['news_no_on_moder'];
		}
	}
}
?>