<?php
class newsadd
{
    private static $additionfields;
	private static $fields;
		
	public function onnewsadd(){
	    ## do it
	}
	
	public function addfields($fields){
	    if ($this->fields == NULL){
		    $this->fields = $fields;
		} else {
		    $this->fields = $this->fields+$fields;
		}
	}
	
	public function returnfields(){
	    if ($this->fields != NULL){
	        return $this->fields;
		} else {
		    return array("" => "");
		}
	}
	
	public function truecat($type){
	$query = db::query("SELECT * FROM ".PREFIX."_news_cats WHERE id='".core::clrtxt($_POST['category'])."'",false);
	  if ($type == NULL){
		$num = @mysql_num_rows($query);
		if ($num > 0){
		    return TRUE;
		} else {
		    return FALSE;
		}
	  } else {
	      $array = @mysql_fetch_array($query);
	      return $array['cat_desc'];
	  }
	}
	
	public function addnews(){
	GLOBAL $lang_err,$validate,$config,$lang;
	    if ($validate->standart($_POST['news_title'],3,100,"!.?!") != TRUE){
		    return $lang_err['news_title_invalid'];
		} elseif ($validate->standart($_POST['news_short'],20,1000,"!.?!") != TRUE){
		    return $lang_err['news_short_invalid'];
		} elseif ($validate->standart($_POST['news_full'],20,5000,"!.?!") != TRUE){
		    return $lang_err['news_full_invalid'];
		} elseif ($this->truecat(null) != TRUE){
            return $lang_err['news_category_invalid'];
        } else {
		
		    if (@$_POST['allow_unreg'] == 'false'){
			    $news_allow_unreg = 0;
			} else {
			    if ($config['allow_news_unreg_default'] == '1'){
			        $news_allow_unreg = 1;
				} else {
				    $news_allow_unreg = 0;
				}
			}
			
			if (@$_POST['allow_comment'] == 'false'){
			    $news_allow_comment = 0;
			} else {
			    if ($config['allow_news_comments_default'] == '1'){
			        $news_allow_comment = 1;
				} else {
				    $news_allow_comment = 0;
				}
			}
			
			$hidden = "0";
			if (@$_POST['hide_news']){
			    $hidden = "1";
			}
			
			db::query("INSERT INTO ".PREFIX."_news SET 
			news_title='".core::clrtxt($_POST['news_title'])."', 
			news_short='".core::clrnfull($_POST['news_short'])."', 
			news_full='".core::clrnfull($_POST['news_full'])."', 
			news_author='".$_SESSION['mylogin']."', 
			news_author_id='".$_SESSION['myid']."',
			news_post_date='".time()."',
			news_allow_unreg='$news_allow_unreg',
			news_allow_comment='$news_allow_comment',
			news_category='".$this->truecat('catdesc')."',
			news_category_id='".$_POST['category']."',
			news_rating='0',
			verified='1',
			news_hidden='$hidden'
			",true);
			$this->onnewsadd();
			return $lang['news_add_succ'];
			
		}
	}
}
?>