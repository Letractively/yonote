<?php
class usertools
{

    public function onadd(){
	    ## do it
	}
	
	public function oninsert(){
	    ## do it
	}
	
	public function onsearch(){
	    ## do it
	}
	
	public function onremove(){
	    ## do it
	}
	
	public function onactivate(){
	    ## do it
	}
	
	public function onmove(){
	    ## do it
	}
	
	public function onedit(){
	    ## do it
	}
	
	public function onupdate(){
	    ## do it
	}
	
	public function onaddgroup(){
	    ## do it
	}
	
	public function oninsertgroup(){
	    ## do it
	}
	
	public function oneditgroup(){
	    ## do it
	}
	
	public function onupdategroup(){
	    ## do it
	}
	
	public function onremovegroup(){
	    ## do it
	}

    public function selectgroups(){
	    $query = db::query("SELECT * FROM ".PREFIX."_usergroup",false);
		$num = @mysql_num_rows($query);
		if ($num > 0){
		    while ($row = @mysql_fetch_array($query)){
			    $result .= "<option value='{$row['category_name']}'>{$row['category_description']}</option>";
			}
			return $result;
		} else {
		    return FALSE;
		}
		
	}
	
    public function showaddform(){
	GLOBAL $lang_err;
	    if ($this->selectgroups() != FALSE){
	        $nobordertmpl = new nobordertmpl;
		    $nobordertmpl->editpath('template/adduser.tpl');
		    $nobordertmpl->add_tags(array("{_CATS_}" => $this->selectgroups()));
			$this->onadd();
		    return $nobordertmpl->templateset();
		} else {
		    return $lang_err['usergrops_no_groups'];
		}
	}
	
	public function adduser(){
	GLOBAL $validate,$lang_err;
	GLOBAL $lang;
	    if ($validate->check_login(strip_tags($_POST['user_login']),strip_tags($_POST['user_mail'])) != TRUE){
		    return $lang_err['adduser_loginormail_invalid'];
		} elseif ($validate->standart($_POST['user_login'],3,19,"/[A-Za-z0-9_]/i") != TRUE){
		    return $lang_err['adduser_login_invalid'];
		} elseif ($validate->standart($_POST['user_password'],6,22,"/[a-z0-9]/i") != TRUE){
		    return $lang_err['adduser_password_invalid'];
		} elseif ($validate->standart($_POST['user_mail'],5,50,"/[0-9a-z_]+@[0-9a-z_^\.]+\.[a-z]{2,3}/i") != TRUE){
		    return $lang_err['adduser_mail_invalid'];
		} else {
		    if (@$_POST['user_admin']){
			    $user_admin="user_admin='1'";
			} else {
			    $user_admin="user_admin='0'";
			}
			
			db::query("INSERT INTO ".PREFIX."_user SET 
			user_login='".strip_tags(core::clrtxt($_POST['user_login']))."',
			user_password='".strip_tags(core::clrtxt(md5($_POST['user_password'])))."',
			user_mail='".strip_tags(core::clrtxt($_POST['user_mail']))."',
			user_group='".core::clrtxt($_POST['group'])."',
            user_activate='1',
			user_blocked='0',
			user_banned='0',
			user_verified='1',
			user_cant_add_comm='0',
			$user_admin",true);
			$this->oninsert();
			return $lang['useradd_succ'];
		}
	}
	
	public function usertoolsshow(){
	GLOBAL $lang_err;
	  if ($this->userlist(null,null) != FALSE){
	    if ($this->selectgroups() != FALSE){
	        $nobordertmpl = new nobordertmpl;
	        $nobordertmpl->editpath('template/usertools.tpl');
		    $nobordertmpl->add_tags(array("{_CATS_}" => $this->selectgroups(), "{_USERLIST_}" => $this->userlist(null,null)));
		    return $nobordertmpl->templateset();
		} else {
		    return $lang_err['usergrops_no_groups'];
		}
	  } else {
	      return $lang_err['users_nousers_toshow'];
	  }
	}
	
	public function sysnameisset($name){
	    $query = db::query("SELECT * FROM ".PREFIX."_usergroup WHERE category_name='".core::clrtxt($name)."'",false);
		$num = @mysql_num_rows($query);
		if ($num > 0){
		    return TRUE;
		} else {
		    return FALSE;
		}
	}
	
	public function userlist($type,$qr){
	  if ($type == NULL){
	    $query = db::query("SELECT * FROM ".PREFIX."_user ORDER BY id DESC LIMIT 0,200",true);
	  } else {
	    $query = db::query("SELECT * FROM ".PREFIX."_user $qr",true);
	  }
		$num = @mysql_num_rows($query);
		if ($num > 0){
		    $nobordertmpl = new nobordertmpl;
			$nobordertmpl->editpath('template/userlist.tpl');
			
			$counter=1;
		    while ($row = @mysql_fetch_array($query)){
			
				if ($counter == 3){
		            $counter=1;
		        }
		
		        if ($counter == 1){
		            $style = "style='background-color:#00446f'";
		        } else {
		            $style = NULL;
		        }
				
				$nobordertmpl->settags(array(
				"{_ID_}" => $row['id'],
				"{_LOGIN_}" => $row['user_login'],
				"{_EMAIL_}" => $row['user_mail'],
				"{_GROUP_}" => $row['user_group'],
				"{_ACTIVATE_}" => $row['user_activate'],
				"{_STYLE_}" => $style
				));
				
		        $result .= $nobordertmpl->templateset();
				$counter++;
		    }
			return $result;
		} else {
		    return FALSE;
		}
	}
	
	public function find(){
	GLOBAL $lang_err;
	    if(@$_POST['submit'] || $_REQUEST['search'] == 'custom'){
		    switch($_REQUEST['stype']){
			    case 'by_id':$qr="WHERE id=".core::clrtxt($_REQUEST['searchbox'])."";
				break;
				
				case 'by_login':$qr="WHERE user_login LIKE '%".core::clrtxt($_REQUEST['searchbox'])."%'";
				break;
				
				case 'by_email':$qr="WHERE user_mail LIKE '%".core::clrtxt($_REQUEST['searchbox'])."%'";
				break;
				
				case 'by_group':$qr="WHERE user_group LIKE '%".core::clrtxt($_REQUEST['searchbox'])."%'";
				break;
				
				case 'not_act':$qr="WHERE user_activate='0'";
				break;
			}
			
			if ((core::clrtxt($_REQUEST['searchbox']) == NULL) || ($_REQUEST['stype'] == 'by_id' && !preg_match("![0-9]!",$_REQUEST['searchbox']))){
			    return $lang_err['searchbox_empty'];
			} else {
			    $query = db::query("SELECT * FROM ".PREFIX."_user $qr",false);
				$num = @mysql_num_rows($query);
				if ($num == 0){
				    return $lang_err['search_no_result'];
				} else {
				    $query_groups = db::query("SELECT * FROM ".PREFIX."_usergroup",true);
	                while ($row_groups = @mysql_fetch_array($query_groups)){
	                    $cat_list .= "<option value='{$row_groups['category_name']}'>{$row_groups['category_description']}</option>";
	                }
				    $nobordertmpl = new nobordertmpl;
	                $nobordertmpl->editpath('template/usersearchresults.tpl');
					$nobordertmpl->settags(array("{_RESULTS_}" => $this->userlist('search',$qr), "{_CATS_}" => $cat_list));
				    $this->onsearch();
					return $nobordertmpl->templateset();
				}
			}
		} else {
		    core::redirect('index.php?page=users');
		}
	}
	
	public function options(){
	GLOBAL $lang,$lang_err;
	$query = db::query("SELECT * FROM ".PREFIX."_user",true);
	$counter=0;
	    if ($_POST['options'] == 'del'){
		    while ($row = @mysql_fetch_array($query)){
			    if (@$_POST['del_'.$row['id']]){
				  if ($row['id'] == '1'){
				      return $lang_err['users_cant_edit_superadmin'];
				      break;
				  }
				    $counter++;
				    db::query("DELETE FROM ".PREFIX."_user WHERE id='{$row['id']}'",true); // Delete user
					db::query("DELETE FROM ".PREFIX."_news WHERE news_author_id='{$row['id']}'",true); // Delete all users news
					db::query("DELETE FROM ".PREFIX."_comments WHERE  comment_author_id='{$row['id']}'",true); // Delete all users comments
				}
			}
			
			if ($counter > 0){
			    $this->onremove();
			    return $lang['users_deleted'];
			} else {
			    return $lang_err['users_nousers_actions'];
			}
		} elseif ($_POST['options'] == 'markasproven'){
		
		    while ($row = @mysql_fetch_array($query)){
			    if ($row['id'] == '1'){
				      return $lang_err['users_cant_edit_superadmin'];
				      break;
				}
			    db::query("UPDATE ".PREFIX."_user SET user_activate='1' WHERE id='{$row['id']}'",true);
				$counter++;
			}
			if ($counter > 0){
			    $this->onactivate();
			    return $lang['users_marked_as_proved'];
			} else {
			    return $lang_err['users_nousers_actions'];
			}
		} elseif ($_POST['options'] == 'move'){
		    while ($row = @mysql_fetch_array($query)){
			    if ($row['id'] == '1'){
				      return $lang_err['users_cant_edit_superadmin'];
				      break;
				}
			    if (@$_POST['del_'.$row['id']]){
				    $counter++;
				    db::query("UPDATE ".PREFIX."_user SET user_group='".$_POST['newcat']."' WHERE id='{$row['id']}'",true);
				}
			}
			if ($counter > 0){
			    $this->onmove();
			    return $lang['users_moved_selected'];
			} else {
			    return $lang_err['users_nousers_actions'];
			}
		}
	}
	
	public function edit(){
	GLOBAL $lang_err;
	    if ($_GET['id'] == '1' || $_GET['id'] == 1){
		    return $lang_err['users_cant_edit_superadmin'];
		} else {
	    $query = db::query("SELECT * FROM ".PREFIX."_user WHERE id='".core::clrtxt($_GET['id'])."'",false);
		$num = @mysql_num_rows($query);
		if ($num > 0){
		    $row = @mysql_fetch_array($query);
			
			// If user is admin
			if ($row['user_admin'] == '1'){
			    $selected_0 = "selected";
				$selected_1 = NULL;
			} else {
			    $selected_0 = NULL;
				$selected_1 = 'selected';
			}
			
			// If user is activated
			if ($row['user_activate'] == '1'){
			    $selected_2 = "selected";
				$selected_3 = NULL;
			} else {
			    $selected_2 = NULL;
				$selected_3 = 'selected';
			}
			
			// If user verified
			if ($row['user_verified'] == '1'){
			    $selected_10 = 'selected';
				$selected_11 = NULL;
			} else {
			    $selected_10 = NULL;
				$selected_11 = 'selected';
			}
			
			// If user is blocked
			if ($row['user_blocked'] == '1'){
			    $selected_4 = 'selected';
				$selected_5 = NULL;
				$block_time = date("d.m.Y",$row['block_time']);
			} else {
			    $selected_5 = 'selected';
			    $selected_4 = NULL;
				$block_time = NULL;
			}
			
			// If user is banned
			if ($row['user_banned'] == '1'){
			    $selected_6 = 'selected';
				$selected_7 = NULL;
			} else {
			    $selected_6 = NULL;
				$selected_7 = 'selected';
			}
			
			
			// If user can't add comments
			if ($row['user_cant_add_comm'] == '1'){
			    $selected_8 = 'selected';
				$selected_9 = NULL;
				$cant_comment_time = date("d.m.Y",$row['cant_comm_time']);
			} else {
			    $selected_8 = NULL;
				$selected_9 = 'selected';
				$cant_comment_time = NULL;
			}
			
	        $nobordertmpl = new nobordertmpl;
		    $nobordertmpl->editpath('template/edituser.tpl');
		    $nobordertmpl->add_tags(array(
			  "{_CATS_}" => $this->selectgroups(),
			  "{_SELECTED_0_}" => $selected_0,
			  "{_SELECTED_1_}" => $selected_1,
			  "{_SELECTED_2_}" => $selected_2,
			  "{_SELECTED_3_}" => $selected_3,
			  "{_SELECTED_4_}" => $selected_4,
			  "{_SELECTED_5_}" => $selected_5,
			  "{_SELECTED_6_}" => $selected_6,
			  "{_SELECTED_7_}" => $selected_7,
			  "{_SELECTED_8_}" => $selected_8,
			  "{_SELECTED_9_}" => $selected_9,
			  "{_SELECTED_10_}" => $selected_10,
			  "{_SELECTED_11_}" => $selected_11,
			  "{_BLOCKTIME_}" => $block_time,
			  "{_CANTCOMMTIME_}" => $cant_comment_time
			));
			$this->onedit();
		    return $nobordertmpl->templateset();
		} else {
		    return $lang_err['users_no_such_user'];
		}
		}
	}
	
	public function update_user(){
	GLOBAL $lang_err,$lang;
	    if ($_GET['id'] != '1'){
		  if ($_POST['user_blocked'] != '1' || ($_POST['user_blocked'] == '1' && preg_match("!^(01|02|03|04|05|06|07|08|09|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31)\.(01|02|03|04|05|06|07|08|09|10|11|12)\.[0-9]{4}$!",$_POST['block_time']))){
		      if ($_POST['user_cant_comment'] != '1' || ($_POST['user_cant_comment'] == '1' && preg_match("!^(01|02|03|04|05|06|07|08|09|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31)\.(01|02|03|04|05|06|07|08|09|10|11|12)\.[0-9]{4}$!",$_POST['cant_comm_time']))){
			    
				if ($_POST['block_time'] != NULL){
				    $dep_block = explode(".",$_POST['block_time']);
			        $day_block = $dep_block[0];
				    $month_block = $dep_block[1];
				    $year_block = $dep_block[2];
				
				    $block = mktime(0,0,0,$month_block,$day_block,$year_block);
				} else {
				    $block = NULL;
				}
				
			    db::query("UPDATE ".PREFIX."_user SET 
				user_admin='".$_POST['user_admin']."',
				user_activate='".$_POST['user_activated']."',
				user_verified='".$_POST['user_verified']."',
				user_blocked='".$_POST['user_blocked']."',
				block_time='".$block."',
				user_banned='".$_POST['user_banned']."',
				user_cant_add_comm='".$_POST['user_cant_comment']."',
				cant_comm_time='".$_POST['cant_comm_time']."',
				user_group='".$_POST['user_group']."' 
				WHERE id='".core::clrtxt($_GET['id'])."'",true);
				$this->onupdate();
				return $lang['users_update_succ'];
		  } else {
		      return $lang_err['users_dateformat_error'];
		  }
		      } else {
			      return $lang_err['users_dateformat_error'];
			  }
			
		} else {
		    return $lang_err['users_cant_edit_superadmin'];
		}
	}
	
	public function addgroupform(){
	    $nobordertmpl = new nobordertmpl;
		$nobordertmpl->editpath('template/addgroup.tpl');
		$nobordertmpl->add_tags(array("" => ""));
		$this->onaddgroup();
		return $nobordertmpl->templateset();
	}
	
	public function addgroup(){
	GLOBAL $lang,$lang_err,$validate;
	    if (!$validate->standart($_POST['sys_name'],3,50,"!^[a-zA-Z_]+[a-zA-Z0-9]+$!")){
		    return $lang_err['group_sysname_invalid'];
		} elseif (!$validate->standart($_POST['desc'],3,100,"!^[a-zA-Z�-��-�0-9_ ]+$!")){
		    return $lang_err['group_desc_invalid'];
		} else {
			    if (@$_POST['allow_pm'] && (!$validate->standart($_POST['pm_max'],1,5,"!^[0-9]+$!") || $_POST['pm_max']>50000 || $_POST['pm_max']<1)){
		            return $lang_err['group_pmmaxsize_invalid'];
		        } elseif (@$_POST['gr_blocked'] && !preg_match("!^(01|02|03|04|05|06|07|08|09|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31)\.(01|02|03|04|05|06|07|08|09|10|11|12)\.[0-9]{4}$!",$_POST['block_time'])){
				      return $lang_err['users_dateformat_error'];
			    } elseif ($this->sysnameisset($_POST['sys_name'])){
		              return $lang_err['group_cant_use_sysname'];
		        }  else {
					// If allow add news
				    if (@$_POST['allow_add_news']){
					    $allow_add_news = "1";
					} else {
					    $allow_add_news = "0";
					}
					
					// If allow add comments
				    if (@$_POST['allow_add_comments']){
					    $allow_add_comments = "1";
					} else {
					    $allow_add_comments = "0";
					}
					
					// If allow delete own comments
				    if (@$_POST['allow_del_own_comm']){
					    $allow_del_own_comm = "1";
					} else {
					    $allow_del_own_comm = "0";
					}
					
					// If allow delete all comments
				    if (@$_POST['allow_del_all_com']){
					    $allow_del_all_com = "1";
					} else {
					    $allow_del_all_com = "0";
					}
					
					// Allow edit own comments
				    if (@$_POST['allow_edit_own_com']){
					    $allow_edit_own_com = "1";
					} else {
					    $allow_edit_own_com = "0";
					}
					
					// Group is banned
				    if (@$_POST['is_banned']){
					    $is_banned = "1";
					} else {
					    $is_banned = "0";
					}
					
					// Group is admin
				    if (@$_POST['is_admin']){
					    $is_admin = "1";
					} else {
					    $is_admin = "0";
					}
					
					// Allow to use pm
				    if (@$_POST['allow_pm']){
					    $allow_pm = "1";
					} else {
					    $allow_pm = "0";
					}
					
					// Group is blocked
				    if (@$_POST['gr_blocked']){
					    $is_blocked = "1";
						$date_block = explode(".",$_POST['block_time']);
				        $block_time = mktime(0,0,0,$date_block[1],$date_block[0],$date_block[2]);
					} else {
					    $is_blocked = "0";
						$block_time = NULL;
					}
					
					
					db::query("INSERT INTO ".PREFIX."_usergroup SET 
					category_name='".$_POST['sys_name']."',
					category_description='".$_POST['desc']."',
					can_add_news='$allow_add_news',
					can_add_coments='$allow_add_comments',
					can_delete_own_comments='$allow_del_own_comm',
					can_delete_all_comments='$allow_del_all_com',
					can_edit_own_comments='$allow_edit_own_com',
					is_blocked='$is_blocked',
					block_time='$block_time',
					is_banned='$is_banned',
					is_admin='$is_admin',
					can_use_pm='$allow_pm',
					pm_max_size='".$_POST['pm_max']."'
					",true);
					$this->oninsertgroup();
					return $lang['group_add_succ'];
					
					
				  }
				}
	}
	
	public function grouptools(){
	    $nobordertmpl = new nobordertmpl;
		$nobordertmpl->editpath('template/grouptools.tpl');
		$nobordertmpl->add_tags(array("{_GROUPLIST_}" => $this->grouplist()));
		return $nobordertmpl->templateset();
	}
	
	public function grouplist(){
	    $nobordertmpl = new nobordertmpl;
		$nobordertmpl->editpath('template/grouplist.tpl');
		$query=db::query("SELECT * FROM ".PREFIX."_usergroup ORDER BY id DESC",true);
		$counter=1;
		while ($row = @mysql_fetch_array($query)){
		
		if ($counter == 3){
		    $counter=1;
		}
		
		if ($counter == 1){
		    $style = "style='background-color:#00446f'";
		} else {
		    $style = NULL;
	    }
		
		$nobordertmpl->settags(array(
		  "{_ID_}" => $row['id'],
		  "{_SYSNAME_}" => $row['category_name'],
		  "{_DESC_}" => $row['category_description'],
		  "{_STYLE_}" => $style
		));
		$return .= $nobordertmpl->templateset();
		$counter++;
		}
		return $return;
	}
	
	public function editgroup(){
	GLOBAL $lang,$lang_err;
	    $query = db::query("SELECT * FROM ".PREFIX."_usergroup WHERE id='".core::clrtxt($_GET['id'])."'",false);
		$num = @mysql_num_rows($query);
		if ($num > 0){
		    $row = @mysql_fetch_array($query);
		    $nobordertmpl = new nobordertmpl;
			$nobordertmpl->editpath('template/editgroup.tpl');
			
			## NULL BLOCK ##
			$can_add_news = NULL;
			$can_add_coments = NULL;
			$can_delete_own_comments = NULL;
			$can_delete_all_comments = NULL;
			$can_edit_own_comments = NULL;
			$is_blocked = NULL;
			$block_time = NULL;
			$is_banned = NULL;
			$is_admin = NULL;
			$can_use_pm = NULL;
			$pm_max_size = NULL;
			
			
			if ($row['can_add_news'] == '1'){
			    $can_add_news = "checked";
			}
			if ($row['can_add_coments'] == '1'){
			    $can_add_coments = "checked";
			}
			if ($row['can_delete_own_comments'] == '1'){
			    $can_delete_own_comments = "checked";
			}
			if ($row['can_delete_all_comments'] == '1'){
			    $can_delete_all_comments = "checked";
			}
			if ($row['can_edit_own_comments'] == '1'){
			    $can_edit_own_comments = "checked";
			}
			if ($row['is_blocked'] == '1'){
			    $is_blocked = "checked";
				$block_time = date("d.m.Y",$row['block_time']);
			}
			if ($row['is_banned'] == '1'){
			    $is_banned = "checked";
			}
			if ($row['is_admin'] == '1'){
			    $is_admin = "checked";
			}
			if ($row['can_use_pm'] == '1'){
			    $can_use_pm = "checked";
				$pm_max_size = $row['pm_max_size'];
			}
			
			$nobordertmpl->settags(array(
			  "{_DESC_}" => $row['category_description'],
			  "{_SYSNAME_}" => $row['category_name'],
			  "{_can_add_news_}" => $can_add_news,
			  "{_can_add_coments_}" => $can_add_coments,
			  "{_can_delete_own_comments_}" => $can_delete_own_comments,
			  "{_can_delete_all_comments_}" => $can_delete_all_comments,
			  "{_can_edit_own_comments_}" => $can_edit_own_comments,
			  "{_is_blocked_}" => $is_blocked,
			  "{_block_time_}" => $block_time,
			  "{_is_banned_}" => $is_banned,
			  "{_is_admin_}" => $is_admin,
			  "{_can_use_pm_}" => $can_use_pm,
			  "{_pm_max_size_}" => $pm_max_size
			  
			  
			));
			$this->oneditgroup();
			return $nobordertmpl->templateset();
			
		} else {
		    return $lang_err['group_not_found'];
		}
	}
	
	public function updategroup(){
	GLOBAL $lang_err,$lang,$validate;
	    if (@$_POST['is_blocked'] && !preg_match("!^(01|02|03|04|05|06|07|08|09|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31)\.(01|02|03|04|05|06|07|08|09|10|11|12)\.[0-9]{4}$!",$_POST['block_time'])){
		    return $lang_err['users_dateformat_error'];
		} elseif (@$_POST['can_use_pm'] && (!$validate->standart($_POST['pm_max_size'],1,5,"!^[0-9]+$!") || $_POST['pm_max_size']>50000 || $_POST['pm_max_size']<1)){
		    return $lang_err['group_pmmaxsize_invalid'];
		} elseif (!$validate->standart($_POST['sysname'],3,50,"!^[a-zA-Z_]+[a-zA-Z0-9]+$!")){
		    return $lang_err['group_sysname_invalid'];
		} elseif (!$validate->standart($_POST['desc'],3,100,"!^[a-zA-Z�-��-�0-9_ ]+$!")){
		    return $lang_err['group_desc_invalid'];
		} else {
		    ## UPDATE ##
			
			$allow_add_news = "0";
			$allow_add_comments = "0";
			$allow_delete_own_comments = "0";
			$allow_delete_all_comments = "0";
		    $allow_edit_own_comments = "0";
			$is_blocked = "0";
			$is_banned = "0";
			$is_admin = "0";
			$can_use_pm = "0";
			
			$block_time = NULL;
			$pm_max_size = NULL;
			
			if (@$_POST['allow_add_news']){
			    $allow_add_news = "1";
			}
			if (@$_POST['allow_add_comments']){
			    $allow_add_comments = "1";
			}
			if (@$_POST['allow_delete_own_comments']){
			    $allow_delete_own_comments = "1";
			}
			if (@$_POST['allow_delete_all_comments']){
			    $allow_delete_all_comments = "1";
			}
			if (@$_POST['allow_edit_own_comments']){
			    $allow_edit_own_comments = "1";
			}
			if (@$_POST['is_blocked']){
			    $is_blocked = "1";
				$date_block = explode(".",$_POST['block_time']);
				$block_time = mktime(0,0,0,$date_block[1],$date_block[0],$date_block[2]);
			}
			if (@$_POST['is_banned']){
			    $is_banned = "1";
			}
			if (@$_POST['is_admin']){
			    $is_admin = "1";
			}
			if (@$_POST['can_use_pm']){
			    $can_use_pm = "1";
				$pm_max_size = $_POST['pm_max_size'];
			}
			
			db::query("UPDATE ".PREFIX."_usergroup SET 
			  category_name='".core::clrtxt($_POST['sysname'])."',
			  category_description='".core::clrtxt($_POST['desc'])."',
			  can_add_news='$allow_add_news',
			  can_add_coments='$allow_add_comments',
			  can_delete_own_comments='$allow_delete_own_comments',
			  can_delete_all_comments='$allow_delete_all_comments',
			  can_edit_own_comments='$allow_edit_own_comments',
			  is_blocked='$is_blocked',
			  block_time='$block_time',
			  is_banned='$is_banned',
			  is_admin='$is_admin',
			  can_use_pm='$can_use_pm',
			  pm_max_size='$pm_max_size'
			WHERE id='".core::clrtxt($_GET['id'])."'",true);
			$this->onupdategroup();
			return $lang['group_edit_succ'];
		}
	}
	
	public function deletegroups(){
	GLOBAL $lang,$lang_err;
	$query = db::query("SELECT * FROM ".PREFIX."_usergroup",true);
	$counter = 0;
	while ($row = @mysql_fetch_array($query)){
	    if (@$_POST['del_'.$row['id']]){
		  if ($row['id'] == '1' || $row['id'] == '2' || $row['id'] == '3' || $row['id'] == '4'){
		      return $lang_err['group_cant_delete'];
			  break;
		  } else {
		    db::query("DELETE FROM ".PREFIX."_usergroup WHERE id='{$row['id']}'",false);
		    $counter++;
		  }
		}
	}
	if ($counter > 0){
	    $this->onremovegroup();
	    return $lang['group_delete_succ'];
	} else {
	    return $lang_err['group_no_action_done'];
	}
	}
}
?>