<?php
class cattools
{
	public function onshow(){
	    ## do it
	}
	
	public function onedit(){
	     ## do it
	}
	
	public function onupdate(){
	    ## do it
	}
    
	public function catslist(){
	GLOBAL $lang_err;
	    $query = db::query("SELECT * FROM ".PREFIX."_news_cats ORDER BY id DESC",true);
		$num = @mysql_num_rows($query);
		if ($num > 0){
	        $nobordertmpl = new nobordertmpl;
		    $nobordertmpl->editpath('template/catslist.tpl');
			$counter=1;
			while ($row = @mysql_fetch_array($query)){
			    if ($counter == 3){
		            $counter=1;
		        }
		
		        if ($counter == 1){
		            $style = "style='background-color:#00446f'";
		        } else {
		            $style = NULL;
		        
				}
				
			    $nobordertmpl->settags(array("{_ID_}" => $row['id'], "{_DESC_}" => $row['cat_desc'], "{_NAME_}" => $row['cat_name'], "{_STYLE_}" => $style));
				$result .= $nobordertmpl->templateset();
				
				$counter++;
			}
			return $result;
		} else {
		    return $lang_err['no_cats_specified'];
		}
		
	}

    public function showforms(){
	GLOBAL $lang_err;
	    $query_cats = db::query("SELECT * FROM ".PREFIX."_news_cats",true);
		$num = @mysql_num_rows($query_cats);
		if ($num > 0){
	    while ($row_cats = @mysql_fetch_array($query_cats)){
	        $cat_list .= "<option value='{$row_cats['id']}'>{$row_cats['cat_desc']}</option>";
	    }
	    $nobordertmpl = new nobordertmpl;
		$nobordertmpl->editpath('template/cattools.tpl');
		$nobordertmpl->settags(array("{_CONTENT_}" => $this->catslist(), "{_CATS_}" => $cat_list));
		$this->onshow();
		return $nobordertmpl->templateset();		
		} else {
		    return $lang_err['no_cats_specified'];
		}
	}
	
	public function deletecats(){
	GLOBAL $lang_err,$lang;
	    $counter=0;
	    $query=db::query("SELECT * FROM ".PREFIX."_news_cats",true);
	    if ($_POST['do'] == '1'){
		    $query_moveto = db::query("SELECT * FROM ".PREFIX."_news_cats WHERE id='".core::clrtxt($_POST['cats'])."'",true);
		    $row_moveto = @mysql_fetch_array($query_moveto);
		    while($row=@mysql_fetch_array($query)){
			    if (@$_POST['sel_'.$row['id']]){
				    $counter++;
					db::query("DELETE FROM ".PREFIX."_news_cats WHERE id='{$row['id']}'",true);
					db::query("UPDATE ".PREFIX."_news SET news_category_id='{$row_moveto['id']}', news_category='{$row_moveto['cat_desc']}' WHERE news_category_id='{$row['id']}'",true);
				}
			}
		} elseif ($_POST['do'] == '2'){
		    while($row=@mysql_fetch_array($query)){
			    if (@$_POST['sel_'.$row['id']]){
				    $counter++;
					db::query("DELETE FROM ".PREFIX."_news_cats WHERE id='{$row['id']}'",true);
					db::query("DELETE FROM ".PREFIX."_news WHERE news_category_id='{$row['id']}'",true);
				}
			}
		} elseif ($_POST['do'] == '3'){
		    while($row=@mysql_fetch_array($query)){
			    if (@$_POST['sel_'.$row['id']]){
				    $counter++;
					db::query("DELETE FROM ".PREFIX."_news_cats WHERE id='{$row['id']}'",true);
				}
			}
		}
		
		if ($counter > 0){
		    return $lang['cat_tools_upd_succ'];
		} else {
			return $lang_err['cats_no_acts'];
		}
	}
	
	public function catisset($id){
	    $query=db::query("SELECT * FROM ".PREFIX."_news_cats WHERE id='".core::clrtxt($id)."'",true);
		$num = @mysql_num_rows($query);
		if ($num > 0){
		    return $query;
		} else {
		    return FALSE;
		}
	}
	
	public function editcat(){
	GLOBAL $lang_err,$lang;
	$id = $_GET['id'];
	    if ($this->catisset($id) != FALSE){
		    $query = $this->catisset($id);
			$row = @mysql_fetch_array($query);
			$nobordertmpl = new nobordertmpl;
			$nobordertmpl->editpath('template/editcat.tpl');
			$nobordertmpl->add_tags(array("{_DESC_}" => $row['cat_desc'], "{_NAME_}" => $row['cat_name'], "{_ID_}" => $row['id']));
		    $this->onedit();
			return $nobordertmpl->templateset();	    
		} else {
		    return $lang_err['cats_no_such_cat'];
		}
	}
	
	public function update(){
    GLOBAL $validate,$lang,$lang_err;
	    if (!$validate->standart($_POST['cat_desc'],2,100,"![�-��-�a-zA-Z0-9]!")){
		    return $lang_err['cats_desc_invalid'];
		} elseif (!$validate->standart($_POST['cat_name'],2,30,"![a-zA-Z0-9_]!")){
		    return $lang_err['cats_name_invalid'];
		} elseif (preg_match("![[:space:]]!",$_POST['cat_name'])){
		    return $lang_err['cats_name_invalid'];
		} else {
		    db::query("UPDATE ".PREFIX."_news_cats SET
			cat_name='".core::clrtxt($_POST['cat_name'])."',
			cat_desc='".core::clrtxt($_POST['cat_desc'])."'
			 WHERE id='".core::clrtxt($_GET['id'])."'",true);
			 $this->onupdate();
			return $lang['cat_edit_succ'];
		}
	}
}
?>