<?php
function loadmodules(){
GLOBAL $db;
    $query = $db->query("SELECT * FROM ".PREFIX."_modules WHERE installed='1'",true);
	$num = @mysql_num_rows($query);
	if ($num > 0){
	    while ($row = @mysql_fetch_array($query)){
		    require_once("../engine/modules/{$row['module_name']}/functions/{$row['module_name']}.admin.php");
		}
	}
}
?>