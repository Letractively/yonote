<?php
function check_user_lang(){
    $lang_user = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
	
	$scan_lang = scandir('languages');
	foreach ($scan_lang as $key => $val){
	  if ($val != '.' && $val != '..'){
	      $lang_scan_array[$key] = $val;
	  }
	}
	
	if (!in_array($lang_user, array_values($lang_scan_array))){
	    $lang = 'en';
	} elseif (in_array($lang_user, array_values($lang_scan_array))){
	    $lang = $lang_user;
	}
	
	return $lang;
}


function load_user_lang(){
    $scan_lang = scandir('languages/'.check_user_lang());
	foreach ($scan_lang as $key => $val){
	    if ($val != '.' && $val != '..'){
		    if (preg_match("!.(.lang.php)!",$val)){
			    require_once('languages/'.check_user_lang().'/'.$val);
			}
		}
	}
	
}
?>