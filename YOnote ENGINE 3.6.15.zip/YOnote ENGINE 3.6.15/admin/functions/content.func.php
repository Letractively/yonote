<?php
    function content(){
	GLOBAL $lang,$news,$lang_err,$newsadd,$newstools,$addcat;
	GLOBAL $cattools,$usertools,$comments,$update,$pages,$mods;
	GLOBAL $settings,$uploads;
	$nobordertmpl = new nobordertmpl;
	    if (PAGE == NULL){
		    return $lang['main'];
		} elseif (PAGE == 'news'){
		    if ($_GET['act'] == 'new'){
			    if (@$_POST['submit']){
		            return $newsadd->addnews();  
				} else {
				    $categories = $news->select_cats();
					if ($categories == FALSE){
					    return $lang_err['no_cats_specified'];
					} else {
				        $nobordertmpl->editpath('template/newsadd.tpl');
	                    $nobordertmpl->settags(array("{_CATS_}" => $categories));
						
						$newsadd->addfields(array("" => ""));
						
						$nobordertmpl->add_tags($newsadd->returnfields());
                        return $nobordertmpl->templateset();
					}
				}
			} elseif ($_GET['act'] == 'tools'){
			    if (!@$_POST['submit']){
                    return $newstools->showtools();
				} else {
				    return $newstools->newsoptions();
				}
            } elseif ($_GET['act'] == 'find'){
                return $newstools->findnews();
            } elseif ($_GET['act'] == 'edit'){
			    if (!@$_POST['submit']){
                    return $newstools->editnews();
				} else {
				    return $newstools->updatenews();
				}
            } elseif ($_GET['act'] == 'addcat'){
			    if (@$_POST['submit']){
				    return $addcat->addnewcat();
				} else {
                    return $addcat->showforms();
				}
            } elseif ($_GET['act'] == 'moder'){
			    return $newstools->newsneedmoder();
			} elseif ($_GET['act'] == 'cattools'){
			    if (!@$_POST['submit']){
                    return $cattools->showforms();
				} else {
				    return $cattools->deletecats();
				}
            } elseif ($_GET['act'] == 'editcat'){
			    if (!@$_POST['submit']){
                    return $cattools->editcat();
				} else {
				    return $cattools->update();
				}
            } elseif ($_GET['act'] == 'modercomments'){
			  if ($_GET['subact'] == 'accept'){
			      return $comments->accept($_GET['id']);
			  } elseif ($_GET['subact'] == 'reject'){
			      return $comments->reject($_GET['id']);
			  } else {
			      return $comments->showlist();
			  }
			} else {
			    $nobordertmpl->editpath('template/newsactions.tpl');
			    $nobordertmpl->settags(array(""=>""));
		        return $nobordertmpl->templateset();
			}
		} elseif (PAGE == 'users'){
		    if ($_GET['act'] == 'new'){
			    if (@$_POST['submit']){
				    return $usertools->adduser();
				} else {
			        return $usertools->showaddform();
				}
			} elseif ($_GET['act'] == 'tools'){
			  if (!@$_POST['submit']){
			    return $usertools->usertoolsshow();
			  } else {
			      return $usertools->options();
			  }
			} elseif ($_GET['act'] == 'find'){
			    return $usertools->find();
			} elseif ($_GET['act'] == 'edit'){
			  if (!@$_POST['submit']){
                  return $usertools->edit();
			  } else {
			      return $usertools->update_user();
			  }
            } elseif ($_GET['act'] == 'addgroup'){
			  if (!@$_POST['submit']){
			    return $usertools->addgroupform();
			  } else {
			    return $usertools->addgroup();
			  }
			} elseif ($_GET['act'] == 'grouptools'){
			    if (@$_POST['submit']){
				    return $usertools->deletegroups();
				} else {
			        return $usertools->grouptools();
				}
			} elseif ($_GET['act'] == 'editgroup'){
			  if (!@$_POST['submit']){
			    return $usertools->editgroup();
		      } else {
			    return $usertools->updategroup();
			  }
			} else {
		        $nobordertmpl->editpath('template/useractions.tpl');
		        $nobordertmpl->settags(array(""=>""));
		        return $nobordertmpl->templateset();
			}
		} elseif (PAGE == 'update'){
		  if ($_GET['act'] == 'check'){
		    return $update->check();
		  } else {
		    return $update->main();
		  }
		} elseif(PAGE == 'pages'){
		    if ($_GET['act'] == 'add'){
			  if (!@$_POST['submit']){
			    return $pages->addpage();
			  } else {
			      return $pages->submit();
			  }
			} elseif ($_GET['act'] == 'pagetools'){
			    if (!@$_POST['submit']){
			        return $pages->pagetools();
				} else {
				    return $pages->delete();
				}
			} elseif ($_GET['act'] == 'edit'){
			    if (!@$_POST['submit']){
			        return $pages->edit();
				} else {
				    return $pages->update();
				}
			} else {
		        return $pages->pageactions();
			}
		} elseif (PAGE == 'mods'){
		    if ($_GET['act'] == 'list'){
			  if (!@$_POST['submit']){
		        return $mods->modtools('all');
		      } else {
			    return $mods->options();
			  }
			} elseif ($_GET['act'] == 'installed'){
			    return $mods->modtools('installed'); 
			} elseif ($_GET['act'] == 'modset'){
			    return $mods->modsets();
			} else {
			    return $mods->modsactions();
			}
		} elseif (PAGE == 'settings'){
		    if ($_GET['act'] == 'preferences'){
			    if (!@$_POST['submit']){
			        return $settings->preferences();
				} else {
				    return $settings->prefupdate();
				}
			} elseif ($_GET['act'] == 'public'){
			    if (!@$_POST['submit']){
			        return $settings->pubdeforms();
				} else {
				    return $settings->publicupdate();
				}
			} elseif ($_GET['act'] == 'userpref'){
			    if (!@$_POST['submit']){
				    return $settings->userpref();
				} else {
				    return $settings->updateuserpref();
				}
			} elseif ($_GET['act'] == 'system'){
			    if (!@$_POST['submit']){
				    return $settings->systempref();
				} else {
				     return $settings->updsyspref();
				}
			} else {
		        return $settings->main();
			}
		} elseif (PAGE == 'files'){
		    if ($_GET['act'] == 'upload'){
			    if (@$_POST['submit']){
		             return $uploads->save();
				} else {
				     return $uploads->uploadform();
				}
			} elseif ($_GET['act'] == 'list'){
			    if ($_GET['subact'] == 'img'){
				    return $uploads->showImgs();
				} elseif ($_GET['subact'] == 'files'){
				    return $uploads->showFiles();
				}
			} elseif ($_GET['act'] == 'remove'){
			    if ($_GET['subact'] == 'img'){
				    return $uploads->remove('img');
				} elseif ($_GET['subact'] == 'file'){
				    return $uploads->remove('file');
				}
			} else {
			    return $uploads->mainUploads();
			}
		} else {
		    return $lang_err['page_not_found'];
		}
	
	}
?>