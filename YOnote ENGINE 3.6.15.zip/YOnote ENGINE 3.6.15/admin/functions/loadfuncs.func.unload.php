<?php
function load_functions(){
$load_funcs = scandir('functions');
foreach ($load_funcs as $key => $val){
	    if ($val != '.' && $val != '..'){
		    if (preg_match("!.(.func.php)!",$val)){
			    require_once('functions/'.$val);
			}
		}
}
}
?>