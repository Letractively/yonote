<?php
function is_logged(){
    if (isset($_SESSION['mylogin']) && isset($_SESSION['logged']) && isset($_SESSION['myid']) && $_SESSION['logged']==md5($_SESSION['mylogin']).md5($_SESSION['myid'])){
	    $query = db::query("SELECT * FROM ".PREFIX."_user WHERE user_login='{$_SESSION['mylogin']}' AND id='{$_SESSION['myid']}' AND user_admin='1'",true);
		$num = @mysql_num_rows($query);
		if ($num == 1){
		    return TRUE;
		} else {
		    $query = db::query("SELECT * FROM ".PREFIX."_user WHERE user_login='{$_SESSION['mylogin']}' AND id='{$_SESSION['myid']}'",false);
			$row = @mysql_fetch_array($query);
			$query = db::query("SELECT * FROM ".PREFIX."_usergroup WHERE category_name='{$row['user_group']}' AND is_admin='1'",false);
		    $num = @mysql_num_rows($query);
			if ($num > 0){
			    return TRUE;
			} else {
			    return FALSE;
			}
		}
	} else {
	    return FALSE;
	}
}
?>