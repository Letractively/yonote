<?php
if (!defined("YONOTE_ENGINE")){
    die( 'Hacking attemp!' );
}

define(ROOT_DIR,dirname(__FILE__),true);
define (PAGE,$_GET['page'],true);

/* Check Installation */
if (!file_exists(ROOT_DIR . '/engine/functions/mysql.func.php')){
   echo "<meta http-equiv='Refresh' content='0; /installation/index.php'></meta>";
   die();
}


// Preload main functions, that shouldn't be loaded automatically
require_once('engine/functions/language.func.unload.php');
require_once('engine/functions/loadfuncts.func.unload.php');

## LOAD ENGINE FUNCTIONS ##
load_functions(); // Load functions automatically

## CONFIGURATE SYSTEM AND LOAD SYSTEM FILES ##
load_user_lang(); // Load ENGINE languages
load_mysql_def(); // Connect to MySQL Database
$db = new db; // DB functions
$db->connect(); // Connect to MySQL Database
load_cfg();   // Load configuration | $config - global configuration array
loadgroup(); // Load usergroup configurations | $group_cfg - global usergroup configurations
load_user_conf();
check_block(); // Check if user or usergroup is banned or blocked
ajax_load(); // Load ajax functions
update_ajax(); // Update ajax security


define(TPL_SET,'/templates/'.$config['site_template'],true);
define(TEMPLATE,ROOT_DIR . '/templates/'.$config['site_template'],true); // Global constant - template path (templates/current_template_name)

furl();
load_reserved_pages(); // Reserve pages
check_page(); // Check current page
load_user_lang(); // Check user language and load (if isset such language, if not - default 'en')

## DECLARE CLASSES ##
$news = new news; // 
$noborder_template = new nobordertmpl;    // Template class, without {BORDER}<..>{/BORDER} tags
$validate = new validate; // Validation class
$register = new register; // Registration module
$template = new template; // Main template class
$comments = new comments; // Comments class
$title = new title;
$ajax = new ajax; // Connect ajax module
$login = new login; // Connect login module
$addnews = new addnews;
$profile = new profile;
$pm = new pm;
$stats = new stats;
$custom = new custom;
$cats = new cats;
$sitemap = new sitemap;


## CONFIGURATE CLASSES ##
$news->settags(news::$news_tags); // Option for developers. Allows to add new tags to *_news.tpl (Read the official documentation)

load_module();
?>