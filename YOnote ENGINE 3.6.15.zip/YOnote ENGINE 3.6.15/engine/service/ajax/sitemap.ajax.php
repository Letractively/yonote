<?php
    function ajax_sitemap(){
	
	}
?>