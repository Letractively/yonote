<?php
function ajax_loadbar(){
    return "
	<div id='engine_loadbar' class='engine_loadbar'>
	    <img class='loadicon' />
	</div>
	";
}
?>