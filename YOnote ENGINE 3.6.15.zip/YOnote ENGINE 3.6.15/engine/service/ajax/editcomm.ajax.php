<?php
function ajax_editcomment(){

}

?>