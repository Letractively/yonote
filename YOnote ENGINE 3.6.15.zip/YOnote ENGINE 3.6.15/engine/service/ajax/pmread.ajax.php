<?php
function ajax_pmread(){

}
?>