<?php
function ajax_editprofile(){

}
?>