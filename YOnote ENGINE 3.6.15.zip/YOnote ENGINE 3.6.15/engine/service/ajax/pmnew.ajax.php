<?php
function ajax_pmnew(){

}
?>