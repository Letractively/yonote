<?php
    function ajax_addcomment(){
	GLOBAL $ajax,$lang_err,$lang,$config;
	if (is_logged() == FALSE){
	    return "
		    <script type='text/javascript'>
			
var mscomment=document.getElementsByName('comment');
var captcha=document.getElementsByName('captcha');
var id = document.getElementsByName('id');
var result;
function makeRequest() {
".($ajax->new_object('http_request'))."
".($ajax->set_mimetype())."
 
 
".($ajax->onreadystate("function() { alertContents(".($ajax->obj())."); }"))."
".($ajax->open('POST','"/ajax.php?act=addcomm"',true))."
".($ajax->send('"ajax=1&ajaxcode='.$config['ajax_code'].'&message="+mscomment.item(0).value+"&captcha="+captcha.item(0).value+"&id="+id.item(0).value'))."
 }
 
 function refresh_page(){
     location.reload(true);
 }
 
 function check_res(code){
     switch (code){

	     case '0':$.prompt('".($lang_err['comments_invalid_field_reg'])."');
		 break;
		 
		 case '1':$.prompt('".($lang['comment_add_succ'])."',{callback: refresh_page });
		 break;

		 case '2':$.prompt('".($lang_err['comments_invalid_field_reg'])."');
		 break;

		 case '3':$.prompt('".($lang_err['comment_captcha_invalid'])."');
		 break;
		 
		 case '4':$.prompt('".($lang['comment_add_succ'])."',{callback: refresh_page });
		 break;
		 
		 case '6':$.prompt('".($lang['comment_add_succ_mod'])."',{callback: refresh_page });
		 break;

		 case '5':$.prompt('".($lang_err['comment_ajax_error'])."');
		 break;
		 
		 default:$.prompt('AJAX ERROR!');
		 break;
	 }
 }
 function alertContents(".($ajax->obj()).") {
     if (".($ajax->obj()).".readyState == 4) {
        if (".($ajax->obj()).".status == 200) {
             result=".($ajax->responsetext()).";
			 check_res(result);
        } else {
            $.prompt('AJAX ERROR!');
        }
     } else {
	     if (".($ajax->obj()).".readyState == 1){
		     $('#engine_loadbar').removeClass('engine_loadbar');
			 $('#engine_loadbar').addClass('engine_loadbar_on');
		 } else {
		     $('#engine_loadbar').removeClass('engine_loadbar_on');
			 $('#engine_loadbar').addClass('engine_loadbar');
		 }
	 }
 }
			</script>
		";
	} else {
	return "
		    <script type='text/javascript'>
			
var mscomment=document.getElementsByName('comment');
var id = document.getElementsByName('id');
var result;
function makeRequest() {
".($ajax->new_object('http_request'))."
".($ajax->set_mimetype())."
 
 
".($ajax->onreadystate("function() { alertContents(".($ajax->obj())."); }"))."
".($ajax->open('POST','"/ajax.php?act=addcomm"',true))."
".($ajax->send('"ajax=1&ajaxcode='.$config['ajax_code'].'&message="+mscomment.item(0).value+"&id="+id.item(0).value'))."
 }
 
 function refresh_page(){
     location.reload(true);
 }
 
 function check_res(code){
     switch (code){

	     case '0':$.prompt('".($lang_err['comments_invalid_field_reg'])."');
		 break;
		 
		 case '1':$.prompt('".($lang['comment_add_succ'])."',{callback: refresh_page });
		 break;

		 case '2':$.prompt('".($lang_err['comments_invalid_field_reg'])."');
		 break;

		 case '3':$.prompt('".($lang_err['comment_captcha_invalid'])."');
		 break;
		 
		 case '4':$.prompt('".($lang['comment_add_succ'])."',{callback: refresh_page });
		 break;
		 
		 case '6':$.prompt('".($lang['comment_add_succ_mod'])."',{callback: refresh_page });
		 break;

		 case '5':$.prompt('".($lang_err['comment_ajax_error'])."');
		 break;
		 
		 default:$.prompt('AJAX ERROR!');
		 break;
	 }
 }
 function alertContents(".($ajax->obj()).") {
     if (".($ajax->obj()).".readyState == 4) {
        if (".($ajax->obj()).".status == 200) {
             result=".($ajax->responsetext()).";
			 check_res(result);
        } else {
            $.prompt('AJAX ERROR!');
        }
     } else {
	     if (".($ajax->obj()).".readyState == 1){
		     $('#engine_loadbar').removeClass('engine_loadbar');
			 $('#engine_loadbar').addClass('engine_loadbar_on');
		 } else {
		     $('#engine_loadbar').removeClass('engine_loadbar_on');
			 $('#engine_loadbar').addClass('engine_loadbar');
		 }
	 }
 }
			</script>
		";
	}
}
?>