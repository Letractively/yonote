<?php
    function ajax_register(){
	GLOBAL $ajax,$lang_err,$lang,$config;
	    return "
		    <script type='text/javascript'>
var login=document.getElementsByName('login');
var password=document.getElementsByName('password');
var repass=document.getElementsByName('repass');
var mail=document.getElementsByName('mail');
var captcha=document.getElementsByName('captcha');
var result;
function makeRequest() {

".($ajax->new_object('http_request'))."
".($ajax->set_mimetype())."
 
 
".($ajax->onreadystate("function() { alertContents(http_request); }"))."
".($ajax->open('POST','"ajax.php?act=regvalidate"',true))."
".($ajax->send('"ajax=1&ajaxcode='.$config['ajax_code'].'&login="+login.item(0).value+"&password="+password.item(0).value+"&repass="+repass.item(0).value+"&mail="+mail.item(0).value+"&captcha="+captcha.item(0).value'))."
 }
 
 function refresh_page(){
     location.reload(true);
 }
 
 function check_res(code){
     switch (code){
	     case '0':$.prompt('".($lang_err['register_login_invalid'])."');
		 break;

		 case '1':$.prompt('".($lang_err['register_login_or_email_registered'])."');
		 break;
		 
		 case '2':$.prompt('".($lang_err['register_password_invalid'])."');
		 break;
		 
		 case '3':$.prompt('".($lang_err['register_password_re_invalid'])."');
		 break;
		 
		 case '4':$.prompt('".($lang_err['register_email_invalid'])."');
		 break;
		 
		 case '5':$.prompt('".($lang_err['register_captcha_invalid'])."');
		 break;
		 
		 case '6':$.prompt('".($lang['register_success'])."',{callback: refresh_page });
		 break;
		 
		 case '7':$.prompt('".($lang['register_need_verification'])."',{callback: refresh_page });
		 break;
		 
		 case '8':$.prompt('".($lang['register_need_acc_and_email_activation'])."',{callback: refresh_page });
		 break;
		 
		 case '9':$.prompt('".($lang['register_need_acc_activation'])."',{callback: refresh_page });
		 break;
		 
		 default:$.prompt(code);
		 break;
	 }
 }
 
 function alertContents(".($ajax->obj()).") {
     if (".($ajax->obj()).".readyState == 4) {
        if (".($ajax->obj()).".status == 200) {
             result=".($ajax->responsetext()).";
			 check_res(result);
        } else {
            $.prompt('AJAX ERROR!');
        }
     } else {
	     if (".($ajax->obj()).".readyState == 1){
		     $('#engine_loadbar').removeClass('engine_loadbar');
			 $('#engine_loadbar').addClass('engine_loadbar_on');
		 } else {
		     $('#engine_loadbar').removeClass('engine_loadbar_on');
			 $('#engine_loadbar').addClass('engine_loadbar');
		 }
	 }
 }
			</script>
		";
	}
?>