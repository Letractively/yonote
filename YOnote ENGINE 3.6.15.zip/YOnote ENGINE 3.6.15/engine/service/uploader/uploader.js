function error_type_1(){
    $.prompt('��������� ������!'); 
	$('.input_file').animate({opacity:'1.0'},500); 
	$('#upload').css({display:'inline'}); 
	$('#loading').css({display:'none'});
	var bgColorNormal = $('#about_file').css('backgroundColor');
	$('#about_file').css({backgroundColor: "red"});
}

function error_type_2(){
    $.prompt('���������������� ������ �����!'); 
	$('.input_file').animate({opacity:'1.0'},500); 
	$('#upload').css({display:'inline'}); 
	$('#loading').css({display:'none'});
	var bgColorNormal = $('#about_file').css('backgroundColor');
	$('#about_file').css({backgroundColor: "red"});
}

$(document).ready(function(){
$('.input_file').change(function(){
    if ($('.input_file').val() != ''){
	    var file = $('.input_file').val();
	    //������� �������� ����� � ��� ����������
		var reWin = /.*\\(.*)/;
	    var fileName = file.replace(reWin, '$1');
		var reUnix = /.*\/(.*)/;
		fileName = fileName.replace(reUnix, '$1');
		var regExExt =/.*\.(.*)/;
		var ext = fileName.replace(regExExt, '$1');
		var pos;
		
		$('#about_file').css({backgroundColor: "#00446f"});
		
				if (ext){
					switch (ext.toLowerCase()) {
						case 'psd': pos = '0'; break;
						case 'txt': pos = '16'; break;                       
						case 'xls': pos = '32'; break;
						case 'png': pos = '48'; break;
						case 'jpg': pos = '64'; break;
						case 'jpeg': pos = '64'; break;
						case 'gif': pos = '80'; break;
						case 'doc': pos = '96'; break;
						case 'zip': pos = '112'; break;
						case 'rar': pos = '112'; break;
						case 'avi': pos = '144'; break;
						case 'wmv': pos = '144'; break;
						case 'flv': pos = '160'; break;
						case 'mp3': pos = '176'; break;
						case 'wav': pos = '192'; break;
						default: pos = '128'; break
					};
					$('#form_img').css({'background-position':('0px -'+pos+'px'),'background-repeat':'no-repeat', 'display':'block'});
				    $('#form_content').html($('.input_file').val());
				};
	}
});


$('#loading').css({display:'none'});
$('#upload').click(function(){
    if ($('.input_file').val() != ''){
			
	} else {
	    $.prompt('�� ������ ����!');
	}
});
});