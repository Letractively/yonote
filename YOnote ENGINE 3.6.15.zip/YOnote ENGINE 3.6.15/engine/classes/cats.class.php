<?php
class cats extends news
{
    public function onallshow(){
	    ## do it
	}
	
	public function newsonshow(){
	    ## do it
	}
	
    public function return_all_cats(){
	GLOBAL $config,$lang,$lang_err;
	GLOBAL $furl;
	
	if ($config['news_cat_sort_type'] == 'descending'){
	    $sort = "DESC";
	} else {
	    $sort = NULL;
	}
	    
		$query = db::query("SELECT * FROM ".PREFIX."_news_cats ORDER BY ".$config['news_cat_sort_by']." $sort",false);
		$num = @mysql_num_rows($query);
		if ($num > 0){
		    $template = new template;
		    $template->editpath(TEMPLATE.'/cats.tpl');
			$template->setbordertag('CATSLIST');
		    while ($row = @mysql_fetch_array($query)){
			    if ($furl == TRUE){
				    $link = array("{_LINK_}" => "/categories/".$row['id']);
				} else {
				    $link = array("{_LINK_}" => "/index.php?page=cats&catid=".$row['id']);
				}
			    $template->settags(array("{_DESC_}" => $row['cat_desc'],"{_CATNAME_}" => $row['cat_name'],"{_CATID_}" => $row['id'])+$link);
				$return_list .= $template->templateset();
			}
		    
		    $template->editpath(TEMPLATE.'/cats.tpl');
		    $template->setbordertag('ALLCATS');
		    $template->settags(array("{_CATLIST_}" => $return_list));
		    $this->onallshow();
		    return $template->templateset();
		} else {
		    return error_info($lang_err['cats_nothing_to_show'],'error');
		}
	}
	
	public function showcatnews(){
	GLOBAL $config;
	    $page = $_GET['p'];
		if ($page == NULL || !preg_match("!^[0-9]+$!",$page)){
		    $page = 0;
		}
		
		$from_news = $config['news_on_page']*$page;
		$this->newsonshow();
		if ($config['sort_type'] == 'descending '){
		    $sort = "DESC";
		} else {
		    $sort = NULL;
		}
		return news::show('short',true,null," WHERE news_category_id='".core::clrtxt($_GET['catid'])."' AND news_hidden='0' ORDER BY ".$config['sort_news_by']."  $sort LIMIT $from_news,{$config['news_on_page']}");
		
	}
}
?>