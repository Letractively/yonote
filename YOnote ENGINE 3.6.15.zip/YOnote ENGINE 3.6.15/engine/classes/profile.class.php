<?php
class profile
{
    private static $additive_fields=array();
	private static $rows=array();
	
	
	// On myprofile show action
	public function onmyprofile(){
	    ## do it
	}
	
	// On myprofile edit action
	public function onedit(){
	    ## do it
	}
	
	// On myprofile onupdate action
	public function onupdate(){
	    ## do it
	}
	
	// On myprofile password change action
	public function onpasswordchange(){
	    ## do it
	}
	
	// On myprofile photo change/set action
	public function onphotoset(){
	    ## do it
	}
	
	// On myprofile photo remove action
	public function onphotoremove(){
	    ## do it
	}
	
	public function add_rows($new_rows){
	  if(profile::$rows != NULL){
	    profile::$rows = profile::$rows+$new_rows;
	  } else {
	    profile::$rows = $new_rows;
	  }
	}
	
	public function return_rows(){
	if (profile::$rows != NULL){
	    $all_rows = count(profile::$rows);
		foreach (profile::$rows as $key => $val){
		    $counter++;
			if ($counter == $all_rows){
			    $return .= " $key='".core::clrtxt($val)."' ";
			} else {
			    $return .= " $key='".core::clrtxt($val)."', ";
			}
		}
	}
	return $return;
	}
	
	public function add_fields($new_fields){
	    if (profile::$additive_fields == NULL){
		    profile::$additive_fields=$new_fields;
		} else {
		    profile::$additive_fields=profile::$additive_fields+$new_fields;
		}
	}
	
    public function ismyprofile(){
	GLOBAL $template,$config,$login,$lang,$lang_err,$user_cfg,$group_cfg;
	if (is_logged() == TRUE){
	    if ($_GET['id'] == NULL){
		    $id = $_SESSION['myid'];
		} else {
	        $id = $_GET['id'];
		}
	    $query = db::query("SELECT * FROM ".PREFIX."_user WHERE id='".core::clrtxt($id)."'",TRUE);
		$num = @mysql_num_rows($query);
		$row = @mysql_fetch_array($query);
	  
	  // Add template
	  $template->editpath(TEMPLATE.'/profile.tpl');
	   if ($_SESSION['myid'] == $_GET['id'] || $_GET['id'] == NULL){
		if ($config['require_email_validation'] == '1' && $config['need_account_activation'] == '1'){
            if ($user_cfg['user_verified'] == '1' && $user_cfg['user_activate'] == '1'){
			    $template->setbordertag('MYPROFILE');
				if ($row['user_photo'] == NULL){
				    $photo = '/uploads/nophoto.jpg';
				} else {
				    $photo = '/uploads/photos/'.$row['user_photo'];
				}
				
				$tags = array(
				    "{_LOGIN_}" => $row['user_login'],
					"{_NAME_}" => $row['user_name'],
					"{_EMAIL_}" => $row['user_mail'],
					"{_LOCATION_}" => $row['user_location'],
					"{_ABOUT_}" => $row['user_about'],
					"{_SIGNATURE_}" => $row['user_signature'],
					"{_PHOTO_}" => $photo
				);
				if (profile::$additive_fields != NULL){
				    $tags = $tags+profile::$additive_fields;
				}
				$template->settags($tags);
				$this->onmyprofile(); // On myprofile show action
				return $template->templateset();
			} else {
			    ## ##
				unset($_SESSION['logged']);
		        unset($_SESSION['mylogin']);
		        unset($_SESSION['myid']);
		        unset($_SESSION['mygroup']);
				return error_info($lang_err['profile_not_ver'],'error');
			}
	   } else {
	      $template->setbordertag('MYPROFILE');
				if ($row['user_photo'] == NULL){
				    $photo = '/uploads/nophoto.jpg';
				} else {
				    $photo = '/uploads/photos/'.$row['user_photo'];
				}
				
				$tags = array(
				    "{_LOGIN_}" => $row['user_login'],
					"{_NAME_}" => $row['user_name'],
					"{_EMAIL_}" => $row['user_mail'],
					"{_LOCATION_}" => $row['user_location'],
					"{_ABOUT_}" => $row['user_about'],
					"{_SIGNATURE_}" => $row['user_signature'],
					"{_PHOTO_}" => $photo
				);
				if (profile::$additive_fields != NULL){
				    $tags = $tags+profile::$additive_fields;
				}
				$template->settags($tags);
				$this->onmyprofile(); // On myprofile show action
				return $template->templateset();
		   
	   }
	  } elseif ($num == 1 && $_GET['id'] != $_SESSION['myid']) {
          $template->setbordertag('SHOWPROFILE');
		  if ($row['user_photo'] == NULL){
				    $photo = '/uploads/nophoto.jpg';
				} else {
				    $photo = '/uploads/photos/'.$row['user_photo'];
				}
				
				$tags = array(
				    "{_LOGIN_}" => $row['user_login'],
					"{_NAME_}" => $row['user_name'],
					"{_EMAIL_}" => $row['user_mail'],
					"{_LOCATION_}" => $row['user_location'],
					"{_ABOUT_}" => $row['user_about'],
					"{_SIGNATURE_}" => $row['user_signature'],
					"{_PHOTO_}" => $photo
				);
				if (profile::$additive_fields != NULL){
				    $tags = $tags+profile::$additive_fields;
				}
				$template->settags($tags);
		  return $template->templateset();
      } else {
          return error_info($lang_err['profile_no_profile'],'error');
      }	  
	} else {
	    core::redirect('/index.php');
	}
	}
	
	public function edit(){
	GLOBAL $template;
	 
	    if (is_logged() == TRUE){
		    $template->editpath(TEMPLATE.'/profile.tpl');
		    $template->setbordertag('EDITPROFILE');
			
			$query = db::query("SELECT * FROM ".PREFIX."_user WHERE user_login='".$_SESSION['mylogin']."' AND id='".$_SESSION['myid']."'",true);
			$row = @mysql_fetch_array($query);
			
			$tags = array(
			  "{_NAME_}" => $row['user_name'],
			  "{_SIGNATURE_}" => $row['user_signature'],
			  "{_LOCATION_}" => $row['user_location'],
			  "{_ABOUT_}" => $row['user_about']
			 );
			 if (profile::$additive_fields != NULL){
				    $tags = $tags+profile::$additive_fields;
			 }
			
			$template->settags($tags);
			$this->onedit(); // On myprofile edit action
			return $template->templateset();
		} else {
		    core::redirect('/index.php');
		}
	}
	
	public function update(){
	GLOBAL $lang,$lang_err,$validate;
	    if (is_logged() == TRUE && @$_POST['submit']){
		    if ($validate->standart($_POST['user_name'],0,40,"/[a-zA-Z�-��-�]/i") != TRUE){
			    return error_info($lang_err['profile_edit_name_invalid'],'error');
			} elseif ($validate->standart($_POST['user_sign'],0,100,"!.?!") != TRUE){
			    return error_info($lang_err['profile_edit_sign_invalid'],'error');
			} elseif ($validate->standart($_POST['user_loc'],0,50,"!.?!") != TRUE){
			    return error_info($lang_err['profile_edit_location_invalid'],'error');
			} elseif ($validate->standart($_POST['about'],0,250,"!.?!") != TRUE){
			    return error_info($lang_err['profile_edit_about_invalid'],'error');
			} else {
			    $rows_sql = array(
				    "user_name" => core::clrtxt($_POST['user_name']),
					"user_signature" => core::clrtxt($_POST['user_sign']),
					"user_location" => core::clrtxt($_POST['user_loc']),
					"user_about" => core::clrtxt($_POST['about'])
				);
			    $this->add_rows($rows_sql);
				$result_sql = $this->return_rows();
			    db::query("UPDATE ".PREFIX."_user SET $result_sql WHERE id='".$_SESSION['myid']."' AND user_login='".$_SESSION['mylogin']."'",true);
			    $this->onupdate(); // On profile update action
				return error_info($lang['profile_edit_succ'],'info');
			}
		} else {
		    core::redirect('./index.php');
		}
	}
	
	public function changepassword(){
	GLOBAL $lang_err,$lang,$validate;
		if (is_logged() == TRUE && @$_POST['submit']){
		    $query = db::query("SELECT * FROM ".PREFIX."_user WHERE user_login='".$_SESSION['mylogin']."' AND id='".$_SESSION['myid']."' AND user_password='".md5(core::clrtxt($_POST['password']))."'",true);
			$row = @mysql_fetch_array($query);
			if ($row['user_password'] == md5($_POST['password'])){
			echo $num;
			    if ($_POST['new_pass'] == $_POST['pass_re'] && $validate->standart($_POST['new_pass'],6,22,"/[a-z0-9]/i") == TRUE){
			        db::query("UPDATE ".PREFIX."_user SET user_password='".md5(core::clrtxt($_POST['new_pass']))."' WHERE user_login='".$_SESSION['mylogin']."' AND id='".$_SESSION['myid']."'",true);
					$this->onpasswordchange(); // On profile password change action
					return error_info($lang['profile_edit_password_change_succ'],'info');
				} else {
				    return error_info($lang_err['profile_edit_password_invalid_re'],'error');
				}
			} else {
			    return error_info($lang_err['profile_no_edit_password'],'error');
			}
		} else {
		    core::redirect('./index.php');
		}
	}
	
	public function checkphoto(){
	GLOBAL $config,$lang,$lang_err;
	$imageinfo = @getimagesize($_FILES['user_photo']['tmp_name']);
	if ($imageinfo == 0){
	    return error_info($lang_err['profile_edit_nullphoto'],'error');
	} else {
	list($width, $height) = $imageinfo;
	$repl = explode(".",(basename($_FILES['user_photo']['name'])));
	$uploadfile = 'uploads/photos/'.strtolower($_SESSION['mylogin']).'.'.($repl[1]);
	    if ($_FILES['user_photo']['type'] == 'image/jpeg' || $_FILES['user_photo']['type'] == 'image/png' || $_FILES['user_photo']['type'] == 'image/gif'){
		                 if ($imageinfo['mime'] == 'image/jpeg' || $imageinfo['mime'] == 'image/png' || $imageinfo['mime'] == 'image/gif'){
			                 if ($_FILES['user_photo']['size'] < $config['userphoto_max_size']){
				              if ($width < $config['userphoto_max_w'] && $height < $config['userphoto_max_h']){
			                    if(move_uploaded_file($_FILES['user_photo']['tmp_name'], $uploadfile)){
								      // Set new photo
					                  db::query("UPDATE ".PREFIX."_user SET user_photo='".strtolower($_SESSION['mylogin']).".".$repl[1]."' WHERE id='".$_SESSION['myid']."' AND user_login='".$_SESSION['mylogin']."'",true);
									  $this->onphotoset(); // On photo set action
									  return error_info($lang['profile_photo_change_succ'],'info');
					            } else {
									return error_info($lang_err['profile_edit_photoupload_error'],'error');
				            	}
			             } else {
			                 return error_info($lang_err['profile_max_img_params'].$config['userphoto_max_w'].'x'.$config['userphoto_max_h'].'','error');
			             }
			             } else {
			                 return error_info($lang_err['profile_max_img_weight'].($config['userphoto_max_size']/1024).$lang['kbytes'],'error');
			             }
		              } else {
		                  return error_info($lang_err['profile_img_not_valid'],'error');
		              }
		             } else {
                        return $_FILES['user_photo']['tmp_name'];
                     }	
	}
	}
	
	public function photo(){
	GLOBAL $config,$lang,$lang_err;
	$valid_photo = glob('uploads/photos/'.strtolower($_SESSION['mylogin']).'.*');
	    if (is_logged() == TRUE && @$_POST['submit']){
		//echo $_FILES['user_photo']['name'];
		    if ($_POST['deletephoto'] == 'true'){
			    // Remove user photo
			    @core::remove($valid_photo[0]);
				db::query("UPDATE ".PREFIX."_user SET user_photo='' WHERE id='".$_SESSION['myid']."' AND user_login='".$_SESSION['mylogin']."'",true);
				$this->onphotoremove(); // On photo remove action
				return error_info($lang['profile_photo_delete_succ'],'info');
			} else{
	            if (sizeof($valid_photo) == 1){
				    // If photo already issets,
					// remove it and upload new
					// one
					db::query("UPDATE ".PREFIX."_user SET user_photo='' WHERE id='".$_SESSION['myid']."' AND user_login='".$_SESSION['mylogin']."'",true);
				    @core::remove($valid_photo[0]);
	                return $this->checkphoto();
	            } else {
	                // Upload photo
					return $this->checkphoto();
	            }
		    }
		} else {
		    core::redirect('./index.php');
		}
	}
}
?>