<?php
class loadconf
{
    public function user_cfg($key){
	    $array = load_user_conf();
		return $array[$key];
	}
	
	public function group_cfg($key){
	    $array = loadgroup();
		return $array[$key];
	}
	
	public function config($key){
	    $array = load_cfg();
		return $array[$key];
	}
}
?>