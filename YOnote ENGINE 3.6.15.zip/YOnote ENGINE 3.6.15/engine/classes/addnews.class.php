<?php
class addnews
{
	
	public function onnewsaddform(){
	    ## do it
	}
	
	public function onnewsadd(){
	    ## do it
	}
   
    // Show "addnews" form
    public function addnews_form(){
	GLOBAL $noborder_template,$lang_err;
		
		if (loadconf::config('news_cat_sort_type') == 'descending'){
	        $sort = "DESC";
	    } elseif (loadconf::config('news_cat_sort_type') == 'ascending'){
	        $sort = NULL;
	    }
		
		if (is_logged() == TRUE && (loadconf::group_cfg('can_add_news') == '1' || loadconf::group_cfg('is_admin') == '1' || loadconf::user_cfg('user_admin') == '1')){
	    $noborder_template->editpath(TEMPLATE.'/addnews.tpl');
		
		$query = db::query("SELECT * FROM ".PREFIX."_news_cats ORDER BY ".loadconf::config('news_cat_sort_by')." $sort",false);
		$num=@mysql_num_rows($query);
		if ($num > 0){
		while ($row = @mysql_fetch_array($query)){
		    $result .= "<option value='".$row['cat_desc']."'>".$row['cat_desc']."</option>";
		}
		
		$noborder_template->add_tags(array("{_CATEGORIES_}"=>$result));
		$this->onnewsaddform();
		return $noborder_template->templateset();
	    } else {
		    return loadconf::config('news_cat_sort_by');
		}
		} else {
	        return error_info(lngforclasses('news_add_cant','lang_err'),'error');
	    }
	}
	
	public function check_news_cat($id,$return_name){
	if ($return_name == FALSE){
	    $query = db::query("SELECT id FROM ".PREFIX."_news_cats WHERE cat_desc='".core::clrtxt($id)."'",true);
		$num = @mysql_num_rows($query);
		if ($num == 1){
		    return TRUE;
		} else {
		    return FALSE;
		}
	} elseif ($return_name == TRUE){
	    $query = db::query("SELECT * FROM ".PREFIX."_news_cats WHERE id='".core::clrtxt($id)."'",true);
		$row = @mysql_fetch_array($query);
		return $row['cat_desc'];
	}
	}
	
	public function add_news(){
	GLOBAL $validate;
	    if (is_logged() == TRUE){
		    if (loadconf::user_cfg('user_admin') == '1' || loadconf::group_cfg('is_admin') == '1' || loadconf::group_cfg('can_add_news') == '1'){
			    if ($validate->standart(strip_tags($_POST['news_title']),3,100,"!.?!") != TRUE){
				    ## TITLE INVALID ##
					return error_info(lngforclasses('news_add_invalid_title','lang_err'),'error'); 
				} elseif ($validate->standart(strip_tags($_POST['news_short']),20,1000,"!.?!") != TRUE){
				    ## SHORT INVALID ##
					return error_info(lngforclasses('news_add_invalid_short','lang_err'),'error'); 
				} elseif ($validate->standart(strip_tags($_POST['news_full']),20,5000,"!.?!") != TRUE){
				    ## FULL INVALID ##
					return error_info(lngforclasses('news_add_invalid_full','lang_err'),'error'); 
				} else {
				    if ($this->check_news_cat($_POST['news_cat'],FALSE) == TRUE){
					    if (loadconf::config('news_need_verification') == '1'){
						    db::query("INSERT INTO ".PREFIX."_news SET news_title='".core::clrtxt($_POST['news_title'])."', news_short='".core::clrnfull($_POST['news_short'])."', news_full='".core::clrnfull($_POST['news_full'])."', news_author='{$_SESSION['mylogin']}', news_author_id='{$_SESSION['myid']}', news_post_date='".time()."', news_allow_unreg='".loadconf::config('allow_news_unreg_default')."', news_allow_comment='0', news_category='".$this->check_news_cat(core::clrtxt($_POST['news_cat']),TRUE)."', news_category_id='".core::clrtxt($_POST['news_cat'])."', news_rating='0', verified='0', news_hidden='1'",true);
						    $this->onnewsadd(); // Action for developers
							return error_info(lngforclasses('news_add_succ_mod','lang'),'info'); 
						} else {
						    db::query("INSERT INTO ".PREFIX."_news SET news_title='".core::clrtxt($_POST['news_title'])."', news_short='".core::clrnfull($_POST['news_short'])."', news_full='".core::clrnfull($_POST['news_full'])."', news_author='{$_SESSION['mylogin']}', news_author_id='{$_SESSION['myid']}', news_post_date='".time()."', news_allow_unreg='".loadconf::config('allow_news_unreg_default')."', news_allow_comment='".loadconf::config('allow_news_comments_default')."', news_category='".$this->check_news_cat(core::clrtxt($_POST['news_cat']),TRUE)."', news_category_id='".core::clrtxt($_POST['news_cat'])."', news_rating='0', verified='1',news_hidden='0'",true);
						    $this->onnewsadd(); // Action for developers
							return error_info(lngforclasses('news_add_succ','lang'),'info'); 
						}
					} else {
					    return error_info(lngforclasses('news_no_cat','lang_err'),'error'); 
					}
				}
			} else {
			    return error_info(lngforclasses('news_add_cant','lang_err'),'error');
			}
		} else {
		    core::redirect('/index.php');
		}
	}
}
?>