<?php
class comments
{

/** * * * * * * * * * * * * * * *  **
  * YOnote Actions (V2 - rebuild)  **
  * Allows you to add some events  **
  * to in-system actions           **
  * * * * * * * * * * * * * * * *  **/
  
	// On comments init
	public function oninit(){
        ## do it
	}
	
	// On comments show
	public function onshow(){
       ## do it
	}
	
	// On comments check
	public function oncheck(){
	    ## do it
	}
	
	// On comments add
	public function onadd(){
	    ## do it
	}
	
	// On comments remove
	public function onremove(){
	    ## do it
	}
	
	// On comments update
	public function onupdate(){
	    ## do it
	}
	
	// On comments edit
	public function onedit(){
	    ## do it
	}
	
	// On all news comments show
	public function onallcomments(){
	    ## do it
	}

    public function registry_comments(){
	GLOBAL $news;
	    $comments_tags = array(
		"{_ADD_COMMENT_}" => $this->commentsadd_init('add'),
		"{_NEWS_ID_}" => $_GET['id'],
		"{_SHOW_COMMENTS_}" => $this->show_comments($_GET['id'],'id')
		);
	    $news->addtags($comments_tags);
	}

    public function allow_comments($id){
	    $query = db::query("SELECT id FROM ".PREFIX."_news WHERE news_allow_comment='1' AND id='".core::clrtxt($id)."'",true);
		$num = @mysql_num_rows($query);
		if ($num == 1){
		    return TRUE;
		} else {
		    return FALSE;
		}
	}
	
	public function commentsadd_init($type){
	GLOBAL $template,$user_cfg,$lang,$lang_err,$group_cfg,$config;
	$template->editpath(TEMPLATE.'/comments.tpl');
	if ($type == 'init'){
        # NULL #
	} elseif ($type == 'add'){
	  if ($this->allow_comments($_GET['id']) == TRUE){
	    if (is_logged() == true){
		    if ($user_cfg['user_cant_add_comm'] == '0'){
			    if ($group_cfg['can_add_coments'] == '1'){
				    $template->setbordertag('ADD_REG');
					if ($config['allow_ajax'] == '1'){
					    $tags = array("{_ALLOW_AJAX_}"=>"button");
					} else {
					    $tags = array("{_ALLOW_AJAX_}"=>"submit");
					}
			        $template->settags($tags);
					$this->oninit(); // On init action
			        return $template->templateset();
				} else {
				    return show_mess($lang_err['comments_you_cant_apply']);
				}
			} else {
			    if ($user_cfg['user_cant_add_comm'] == '1'){
				    if ($user_cfg['cant_comm_time'] < time()){
					    db::query("UPDATE ".PREFIX."_user SET user_cant_add_comm='0' WHERE user_login='{$_SESSION['mylogin']}' AND id='{$_SESSION['myid']}'",true);
						return core::redirect('index.php');
					} elseif ($user_cfg['cant_comm_time'] > time()){
					    return show_mess($lang_err['comments_user_not_allowed'].date("m.d.Y | H:i",$user_cfg['cant_comm_time']));
					}
				}
			}
		} elseif (is_logged() == false){
		    if ($group_cfg['can_add_coments'] == '1' && $config['unreg_can_add_comm'] == '1'){
			    $template->setbordertag('ADD_UNREG');
				if ($config['allow_ajax'] == '1'){
					    $tags = array("{_ALLOW_AJAX_}"=>"button");
					} else {
					    $tags = array("{_ALLOW_AJAX_}"=>"submit");
					}
			    $tags = $tags+array("{_CAPTCHA_}"=>"/engine/service/captcha/kcaptcha/index.php?".session_name().'='.session_id());
			    $template->settags($tags);
			    return $template->templateset();
			} else {
			    return show_mess($lang_err['comments_you_cant_apply']);
			}
		}
	} else {
	    ## NULL ##
	}
	}
	}
	
	public function can_edit_comments($user,$id){
	GLOBAL $template,$user_cfg,$lang,$lang_err,$group_cfg,$config;
	
	if (is_logged() == TRUE){
	    if($user_cfg['user_cant_add_comm'] == '0' && $group_cfg['can_edit_own_comments'] == '1' && $user == $_SESSION['mylogin']){
		    return '<input type="button" id="engine_comment_button" onclick="location.href=\'/index.php?page=news&act=editcomments&id='.$id.'&verf='.(md5($_SESSION['mylogin']).md5($_SESSION['myid'])).'\'" value="��������" />';
		} elseif ($user_cfg['user_admin'] == '1' || $group_cfg['is_admin'] == '1'){
		    return '<input type="button" id="engine_comment_button" onclick="location.href=\'/index.php?page=news&act=editcomments&id='.$id.'&verf='.(md5($_SESSION['mylogin']).md5($_SESSION['myid'])).'\'" value="��������" />';
		} elseif ($user_cfg['user_cant_add_comm'] == '0' && $group_cfg['can_edit_all_comments'] == '1' && $user != $_SESSION['mylogin']){
		    return '<input type="button" id="engine_comment_button" onclick="location.href=\'/index.php?page=news&act=editcomments&id='.$id.'&verf='.(md5($_SESSION['mylogin']).md5($_SESSION['myid'])).'\'" value="��������" />';
		} else { return NULL; }
	}
	}
	
	public function can_remove_comments($user,$id){
	GLOBAL $template,$user_cfg,$lang,$lang_err,$group_cfg,$config;
	
	if (is_logged() == TRUE){
	    if($user_cfg['user_cant_add_comm'] == '0' && $group_cfg['can_delete_own_comments'] == '1' && $user == $_SESSION['mylogin']){
		    return '<input type="button" id="engine_comment_button" onclick="location.href=\'/index.php?page=news&act=removecomments&id='.$id.'&verf='.(md5($_SESSION['mylogin']).md5($_SESSION['myid'])).'\'" value="�������" />';
		} elseif ($user_cfg['user_admin'] == '1' || $group_cfg['is_admin'] == '1'){
		    return '<input type="button" id="engine_comment_button" onclick="location.href=\'/index.php?page=news&act=removecomments&id='.$id.'&verf='.(md5($_SESSION['mylogin']).md5($_SESSION['myid'])).'\'" value="�������" />';
		} elseif ($user_cfg['user_cant_add_comm'] == '0' && $group_cfg['can_delete_all_comments'] == '1' && $user != $_SESSION['mylogin']){
		    return '<input type="button" id="engine_comment_button" onclick="location.href=\'/index.php?page=news&act=removecomments&id='.$id.'&verf='.(md5($_SESSION['mylogin']).md5($_SESSION['myid'])).'\'" value="�������" />';
		} else { return NULL; }
	}
	}
	
	public function show_comments($for,$type){
	GLOBAL $template,$config,$news_allow_comments,$furl;
	if ($config['comments_sort_type'] == 'descending'){
	    $sort_type="DESC";
	} elseif ($config['comments_sort_type'] == 'ascending'){
	    $sort_type=NULL;
	}
	    $template->setbordertag('SHOW');
		if ($type == 'id'){
	        $query = db::query("SELECT * FROM ".PREFIX."_comments WHERE for_news_id='".core::clrtxt($for)."' AND comment_verif='1' ORDER BY ".$config['sort_comments_by']." $sort_type LIMIT 0,".$config['comm_on_news']."",false);
		} elseif ($type == 'all') {
		    $query = db::query("SELECT * FROM ".PREFIX."_comments WHERE for_news_id='".core::clrtxt($for)."' AND comment_verif='1' ORDER BY ".$config['sort_comments_by']." $sort_type",false);
		}
		
		$user_query = db::query("SELECT id,user_photo,user_signature FROM ".PREFIX."_user",false);
		$usersid_arr = array();
		$user_sign = array();
		while ($user_row = @mysql_fetch_array($user_query)){
		    $usersid_arr = $usersid_arr+array($user_row['id'] => $user_row['user_photo']);
			$user_sign = $user_sign + array($user_row['id'] => $user_row['user_signature']);
		}
		
		while($row = @mysql_fetch_array($query)){
		
		if (array_key_exists($row['comment_author_id'],$usersid_arr)){
		    if ($usersid_arr[$row['comment_author_id']] != NULL){
		        $avatar = '/uploads/photos/'.$usersid_arr[$row['comment_author_id']];
			} else {
			    $avatar = '/uploads/nophoto.jpg';

			}
		} else {
		    $avatar = '/uploads/nophoto.jpg';
		}
		
		if ($user_sign[$row['comment_author_id']] != NULL){
		    $sign = $user_sign[$row['comment_author_id']];
		}
		
		
		    if ($row['comment_author_id'] != NULL){
			  if ($furl == TRUE){
			    $link='/profile/'.$row['comment_author_id'];
			  } else {
			    $link='/index.php?page=user&id='.$row['comment_author_id'];
			  }
			} else {
			    $link='#';
			}
		        $tags = array(
			    "{_POST_AUTHOR_}" => $row['comment_author'],
			    "{_POST_DATE_}" => date("m.d.Y",$row['comment_date']),
			    "{_CONTENT_}" => $row['comment_content'],
			    "{_POST_ID_}" => $row['id'],
			    "{_EDIT_}" => $this->can_edit_comments($row['comment_author'],$row['id']),
			    "{_REMOVE_}" => $this->can_remove_comments($row['comment_author'],$row['id']),
			    "{_USERLINK_}" => $link,
				"{_AVATAR_}" => $avatar,
				"{_SIGNATURE_}" => $sign
			    );
				
			
			$template->settags($tags);
		    $return .= $template->templateset();
		}
		$this->onshow(); // Do an action on comments show
		return $return;
	}
	
	public function check_comment($comment){
    GLOBAL $lang_err,$config,$validate,$lang,$user_cfg,$group_cfg;
	$this->oncheck(); // Do action on check_comment
	if (is_logged() == TRUE){
	    if ($user_cfg['user_cant_add_comm'] == '0'){
		    if ($group_cfg['can_add_coments'] == '1'){
			    if ($config['comments_shoud_moderate'] == '1'){
				    $query="INSERT INTO ".PREFIX."_comments SET comment_author='".$_SESSION['mylogin']."', comment_author_id='".$_SESSION['myid']."', comment_content='".core::clrtxt($comment)."', comment_date='".time()."', comment_verif='0', for_news_id='".core::clrtxt($_POST['id'])."'";
				} else {
				    $query="INSERT INTO ".PREFIX."_comments SET comment_author='".$_SESSION['mylogin']."', comment_author_id='".$_SESSION['myid']."', comment_content='".core::clrtxt($comment)."', comment_date='".time()."', comment_verif='1', for_news_id='".core::clrtxt($_POST['id'])."'";
				}
			    if ($validate->standart($comment,3,500,"!.?!") == TRUE){
				    db::query($query,true);
					$this->onadd(); // Action on comment add
					return show_mess($lang['comment_add_succ']);
				} else {
				    return show_mess($lang_err['comments_invalid_field_reg']);
				}
			} else {
			    return show_mess($lang_err['comments_group_not_allowed']);
			}
		} else {
		    return show_mess($lang_err['comments_user_not_allowed']);
		}
	} elseif (is_logged() == FALSE){
	    if ($group_cfg['can_add_coments'] == '1' && $config['unreg_can_add_comm'] == '1'){
		        if ($config['comments_shoud_moderate'] == '1'){
				    $query="INSERT INTO ".PREFIX."_comments SET comment_author='{$lang['engine_guest']}', comment_content='".strip_tags($comment)."', comment_date='".time()."', comment_verif='0', for_news_id='".$_POST['id']."'";
				} else {
				    $query="INSERT INTO ".PREFIX."_comments SET comment_author='{$lang['engine_guest']}', comment_content='".strip_tags($comment)."', comment_date='".time()."', comment_verif='1', for_news_id='".$_POST['id']."'";
				}
			    if ($validate->standart($comment,3,500,"!.?!") == TRUE){
				    db::query($query,true);
					$this->onadd(); // Action on comment add
					return show_mess($lang['comment_add_succ']);
				} else {
				    return show_mess($lang_err['comments_invalid_field_reg']);
				}
		}
	}
    }
	
	
	
	public function check_comments($id,$login,$com,$type){
	  if ($type='auth'){
	    $query=db::query("SELECT * FROM ".PREFIX."_comments WHERE comment_author='".core::clrtxt($login)."' AND comment_author_id='".core::clrtxt($id)."' AND id='".core::clrtxt($com)."'",false);
	  } elseif ($type = 'unsign'){
	    $query=db::query("SELECT * FROM ".PREFIX."_comments WHERE id='".core::clrtxt($com)."'",false); 
	  }
		$num=@mysql_fetch_array($query);
		if ($num>0){
		    return TRUE;
		} else {
		    return FALSE;
		}
	}
	
	public function delete_comment(){
	GLOBAL $user_cfg,$group_cfg,$lang,$lang_err;	
	    if (($user_cfg['user_cant_add_comm'] != '1' && $group_cfg['can_delete_all_comments'] == '1') || $user_cfg['user_admin'] == '1'){
		    if (($user_cfg['user_admin'] == '1' && is_logged()==TRUE ) || $this->check_comments(null,null,$_GET['id'],'unsign')==TRUE && $_GET['verf'] == md5($_SESSION['mylogin']).md5($_SESSION['myid']) || $group_cfg['is_admin'] == '1'){
			  db::query("DELETE FROM ".PREFIX."_comments WHERE id='".core::clrtxt($_GET['id'])."'",true);
			  $this->onremove(); // Action on comment remove
			  return error_info($lang['comment_deleted'],'info');
			} else {
			    return error_info($lang_err['comments_delete_noaccess'],'error');
			}
		} elseif ($user_cfg['user_cant_add_comm'] != '1' && $_GET['verf'] == md5($_SESSION['mylogin']).md5($_SESSION['myid']) && $group_cfg['can_delete_own_comments'] == '1'){
		    if ($this->check_comments($_SESSION['myid'],$_SESSION['mylogin'],$_GET['id'],'auth')==TRUE){
			  db::query("DELETE FROM ".PREFIX."_comments WHERE id='".core::clrtxt($_GET['id'])."'",true);
			  $this->onremove(); // Action on comment remove
			  return error_info($lang['comment_deleted'],'info');
			} else {
			    return error_info($lang_err['comments_delete_noaccess'],'error');
			}
		} else {
		    core::redirect("./index.php");
		}
	}
	
	public function truecomment($id){
	    $query = db::query("SELECT * FROM ".PREFIX."_comments WHERE id='".core::clrtxt($id)."'",true);
		$num = @mysql_num_rows($query);
		if ($num == 1){
		    return TRUE;
		} else {
		    return FALSE;
		}
	}
	
	public function edit_comment(){
	GLOBAL $template,$user_cfg,$group_cfg,$lang_err;
		if (is_logged() == 'TRUE'){
		  if ($this->truecomment($_GET['id']) == TRUE){
		    $template->editpath(TEMPLATE.'/comments.tpl');
		    $template->setbordertag('EDIT');
			if ((($user_cfg['user_admin'] == '1' || $group_cfg['can_edit_all_comments'] == '1' ) && $user_cfg['user_cant_add_comm'] == '0') || $group_cfg['is_admin'] == '1'){
		      
   			    $query=db::query("SELECT * FROM ".PREFIX."_comments WHERE id='".core::clrtxt($_GET['id'])."'",TRUE);
				$row = @mysql_fetch_array($query);
				$template->settags(array("{_CONTENT_}" => $row['comment_content'], "{_POST_ID_}" => $row['id']));
				$this->onedit(); // Action on  comments edit
				return $template->templateset();
			} elseif ($user_cfg['user_cant_add_comm'] == '0' && $group_cfg['can_edit_own_comments'] == '1' && $this->check_comments($_SESSION['myid'],$_SESSION['mylogin'],$_GET['id'],'auth')==TRUE){
                $query=db::query("SELECT * FROM ".PREFIX."_comments WHERE id='".core::clrtxt($_GET['id'])."'",TRUE);
				$row = @mysql_fetch_array($query);			   
			    $template->settags(array("{_CONTENT_}" => $row['comment_content'], "{_POST_ID_}" => $row['id']));
				$this->onedit(); // Action on  comments edit
				return $template->templateset();
			} else {
			    core::redirect('index.php');
			}
		  } else {
		      return error_info($lang_err['comment_id_invalid'],'error');
		  }
		} else {
		    core::redirect('index.php');
		}
	}
	
	public function update_comment(){
	GLOBAL $config,$lang,$lang_err,$user_cfg,$group_cfg,$validate;
	    if (is_logged() == TRUE){
		    if ($this->truecomment($_POST['id']) == TRUE){
			  if ($validate->standart(core::clrtxt($_POST['comment']),3,500,"!.?!") == TRUE){
			    if ((($user_cfg['user_admin'] == '1' || $group_cfg['can_edit_all_comments'] == '1') && $user_cfg['user_cant_add_comm'] == '0') || $group_cfg['is_admin'] == '1'){
					db::query("UPDATE ".PREFIX."_comments SET comment_content='".core::clrtxt($_POST['comment'])."' WHERE id='".core::clrtxt($_POST['id'])."'",true);
					$this->onupdate(); // Action on comments update
					return error_info($lang['comment_edit_succ'],'info');
				} elseif ($user_cfg['user_cant_add_comm'] == '0' && $this->check_comments($_SESSION['myid'],$_SESSION['mylogin'],$_POST['id'],'auth')==TRUE){
                   	if ($config['comments_shoud_moderate'] == '1'){
                        db::query("UPDATE ".PREFIX."_comments SET comment_verif='0' comment_content='".core::clrtxt($_POST['comment'])."' WHERE id='".core::clrtxt($_POST['id'])."'",true);
						$this->onupdate(); // Action on comments update
						return error_info($lang['comment_edit_succ_mod'],'info');
                    } else {
                        db::query("UPDATE ".PREFIX."_comments SET comment_content='".core::clrtxt($_POST['comment'])."' WHERE id='".core::clrtxt($_POST['id'])."'",true);
						$this->onupdate(); // Action on comments update
						return error_info($lang['comment_edit_succ'],'info');
                    }					
				} else {
				    return error_info($lang_err['comment_no_acc_to_edit'],'error');
				}
				} else {
			        return show_mess($lang_err['comments_invalid_field_reg']);
				}
			}
		} else {
		    core::redirect('index.php');
		}
	}
	
	public function news_all_comments(){
	GLOBAL $lang,$lang_err,$template; 
	    $template->editpath(TEMPLATE.'/comments.tpl');
		$template->setbordertag('SHOW');
	    $return = $this->show_comments(core::clrtxt($_GET['id']),'all');
	    if ($return == NULL){
		    return error_info($lang_err['comments_not_found'],'error');
		} else {
		    $template->setbordertag('ALLCOMMENTS');
			$template->settags(array("{_COMMENTSLIST_}" => $return));
			$this->onallcomments();
		    return $template->templateset();
		}
	}
}
?>