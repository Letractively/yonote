<?php
class custom
{
    public function onshow(){
	    ## do it
	}
	
    public function custom_db($name){
	GLOBAL $lang_err;
	    $query=db::query("SELECT * FROM ".PREFIX."_pages WHERE page_name='".core::clrtxt($name)."' AND page_hidden='0'",true);
		$num=@mysql_num_rows($query);
		if ($num == 1){
		    $row = @mysql_fetch_array($query);
		    title::set_title($row['page_title']);
			$this->onshow();
			return $row['page_content'];
		} else {
		    return error_info($lang_err['page_not_found'],'error');
		}
	}
}
?>