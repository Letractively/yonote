<?php
class pm
{	
	
	// On message show
	public function onshow(){
	    ## do it
	}
	
	// On message read
	public function onread(){
	    ## do it
	}
	
	// On addform print
	public function onadd(){
	    ## do it
	}
	
	// On submit action
	public function onsubmit(){
	    ## do it
	}
	
	// On action remove
	public function onactionremove(){
	    ## do it
	}
	
	// On action check as read
	public function onactionread(){
	    ## do it
	}
	
	// On delete action
	public function ondelit(){
	    ## do it
	}
	
	
    public function show($type){
	GLOBAL $furl;
    $template = new template;
	    if ($type == 'inbox'){
		    $template->editpath(TEMPLATE.'/pm.tpl');
		    $template->setbordertag('PMLIST');
			$query = db::query("SELECT * FROM ".PREFIX."_pm WHERE message_to='".$_SESSION['mylogin']."' AND message_type='inbox' ORDER BY id DESC",true);
	        while ($row = @mysql_fetch_array($query)){
			if ($furl == TRUE){
			    $add_it = array("{_FROMLINK_}" => "/profile/".$row['message_from_id'], "{_READ_}" => "/messages/read/".$row['id']);
			} else {
			    $add_it = array("{_FROMLINK_}" => '/index.php?page=user&id='.$row['message_from_id'], "{_READ_}" => '/index.php?page=pm&act=read&id='.$row['id']);
			}
			    $tags =array(
				  "{_FROM_}"=>$row['message_from'],
				  "{_DATE_}" => date("Y.m.d H:i",$row['message_date']),
				  "{_DELNAME_}" => "del_".$row['id'],
				  "{_DELVALUE_}" => $row['id']
				) + $add_it;
				if ($row['message_read'] == '0'){
				    $tags=$tags+array("{_PMTITLE_}"=>'<b>'.$row['message_title'].'</b>');
				} else {
				    $tags=$tags+array("{_PMTITLE_}"=>$row['message_title']);
				}
				$template->settags($tags);
				$return .= $template->templateset();
	        }
			$this->onshow(); // Action on show
			return $return;
			
		}
	}
	
    public function pm_main(){
	GLOBAL $template,$lang_err;
	if (is_logged() == TRUE){
	$new_messages = 0;
	$count = 0;
	
	$query = db::query("SELECT * FROM ".PREFIX."_pm WHERE message_to='".$_SESSION['mylogin']."' AND message_type='inbox'",true);
	while ($row = @mysql_fetch_array($query)){
	    if ($row['message_read'] == '0'){
		    $new_messages++;
		}
		$count++;
	}
	
	    $template->editpath(TEMPLATE.'/pm.tpl');
		$template->setbordertag('MAIN');
		$tags = array(
		    "{_UNREAD_}" => $new_messages
		);
		
		if ($count == 0){
	        $tags=$tags+array("{_PMLIST_}" => $lang_err['pm_no_inbox']);
	    } else {
		    $tags=$tags+array("{_PMLIST_}" => $this->show('inbox'));
		}
		
		$template->settags($tags);
		return $template->templateset();
	} else {
	    core::redirect('/index.php');
	}
	}
	
	public function read(){
	GLOBAL $template,$lang_err,$furl;
	    if (is_logged() == TRUE){
		    $query = db::query("SELECT * FROM ".PREFIX."_pm WHERE message_type='inbox' AND id='".core::clrtxt($_GET['id'])."' AND message_to='".$_SESSION['mylogin']."'",true);
			$num = @mysql_num_rows($query);
			$row = @mysql_fetch_array($query);
			if ($num == 1){
		        $template->editpath(TEMPLATE.'/pm.tpl');
			    $template->setbordertag('READ');
				if ($furl == TRUE){
				    $add_it = array("{_FROMLINK_}" => "/profile/".$row['message_from_id'],"{_REPLY_}" => "/messages/new/".$row['message_from']);
				} else {
				    $add_it = array("{_FROMLINK_}" => 'index.php?page=user&id='.$row['message_from_id'],"{_REPLY_}" => "index.php?page=pm&act=new&for=".$row['message_from']);
				}
                $template->settags(array(
				  "{_PMTITLE_}"=>$row['message_title'],
				  "{_FROM_}"=>$row['message_from'],
				  "{_DATE_}" => date("Y.m.d H:i",$row['message_date']),
				  "{_MESSAGE_}" => $row['message'],
				  "{_DELVALUE_}" => $row['id']
				) + $add_it);
				
				// Update message status
				if ($row['message_read'] == '0'){
				    db::query("UPDATE ".PREFIX."_pm SET message_read='1' WHERE id='".core::clrtxt($_GET['id'])."'",true);
				}
				$this->onread(); // On read action
				return $template->templateset();
			} else {
                return error_info($lang_err['pm_no_such_message'],'error');
            }			
		} else {
		    core::redirect('/index.php');
		}
	}
	
	public function add(){
	GLOBAL $template,$group_cfg,$lang_err;
	    if (is_logged() == TRUE){
		  if ($group_cfg['can_use_pm'] == '1'){
		    $template->editpath(TEMPLATE.'/pm.tpl');
			$template->setbordertag('ADD');
			if (isset($_GET['for'])){
			    $template->settags(array("{_FOR_}" => $_GET['for']));
			} else {
			    $template->settags(array("{_FOR_}" => ""));
			}
			$this->onadd(); // On addform print action
			return $template->templateset();
		  } else {
		      return error_info($lang_err['pm_group_cant'],'error');
		  }
		} else {
		    core::redirect('/index.php');
		}
	}
	
	public function submit(){
	GLOBAL $lang_err,$group_cfg,$validate,$lang;
	    if (is_logged() == TRUE){
		    if ($group_cfg['can_use_pm'] == '1'){
			    if ($validate->standart($_POST['message_title'],3,30,"!.?!") != TRUE){
				    ## INVALID title ##
					return error_info($lang_err['pm_invalid_title'],'error');
				} elseif ($validate->standart($_POST['message'],3,500,"!.?!") != TRUE){
				    ## INVALID MESSAGE ##
					return error_info($lang_err['pm_invalid_message'],'error');
				} elseif (core::real_user(core::clrtxt($_POST['message_for'])) != TRUE){
                    return error_info($lang_err['pm_for_invalid'],'error');
                } else {		
                    $query_usergroup = db::query("SELECT user_group FROM ".PREFIX."_user WHERE user_login='".core::clrtxt($_POST['message_for'])."'",true);
					$row_usergroup = @mysql_fetch_array($query_usergroup);
					
					$query_pmmax = db::query("SELECT pm_max_size FROM ".PREFIX."_usergroup WHERE category_name='".$row_usergroup['user_group']."'",true);
					$row_pmmax = @mysql_fetch_array($query_pmmax);
					
					$query_allmps = db::query("SELECT * FROM ".PREFIX."_pm WHERE message_to='".core::clrtxt($_POST['message_for'])."'",true);
					$num_pms = @mysql_num_rows($query_allmps);
					
					if ($num_pms > $row_pmmax['pm_max_size']){
					    return error_info($lang_err['pm_max_cant_send'],'error');
					} else {
					
					db::query("INSERT INTO ".PREFIX."_pm SET 
					message_type='inbox',
       				message_from='".$_SESSION['mylogin']."',
					message_to='".core::clrtxt($_POST['message_for'])."',
					message_date='".time()."',
					message_read='0',
					message_from_id='".$_SESSION['myid']."',
					message_title='".core::clrtxt($_POST['message_title'])."',
					message='".core::clrtxt($_POST['message'])."'",true);
					$this->onsubmit(); // Action on submit
					return error_info($lang['pm_send'],'info');
					}
				}
			} else {
			    return error_info($lang_err['pm_group_cant'],'error');
			}
		} else {
		    core::redirect('/index.php');
		}
	}
	
	public function pm_action(){
	GLOBAL $lang,$lang_err;
	    if (is_logged() == TRUE){
		    if ($_POST['action'] == 'del'){
			    $query = db::query("SELECT * FROM ".PREFIX."_pm WHERE message_to='{$_SESSION['mylogin']}'",true);
				while ($row = @mysql_fetch_array($query)){
				    if (@$_POST['del_'.$row['id']]){
						$count++;
						db::query("DELETE FROM ".PREFIX."_pm WHERE id='{$row['id']}' AND message_to='{$_SESSION['mylogin']}'",true);
					}
				}
				if ($count == 0){
				    return error_info($lang_err['pm_no_mess_deleted'],'error');
				} else {
				    $this->onactionremove(); // Action on pm mass remove
				    return error_info($lang['pm_deleted'],'info');
				}
			} elseif ($_POST['action'] == 'read'){
			    $query = db::query("SELECT * FROM ".PREFIX."_pm WHERE message_to='{$_SESSION['mylogin']}'",true);
			    while ($row = @mysql_fetch_array($query)){
				    if (@$_POST['del_'.$row['id']]){
						$count++;
						db::query("UPDATE ".PREFIX."_pm SET message_read='1' WHERE id='{$row['id']}'",true);
					}
				}
				if ($count == 0){
				    return error_info($lang_err['pm_no_mess_moved'],'error');
				} else {
				    $this->onactionread(); // Action on message checking as read
				    return error_info($lang['pm_moved'],'info');
				}
			} else {
			    core::redirect('/index.php?page=pm');
			}
		} else {
		    core::redirect('/index.php');
		}
	}
	
	public function del_it(){
	GLOBAL $lang_err,$lang;
	    if (is_logged() == TRUE && $_GET['id'] != NULL){
		    $query = db::query("SELECT * FROM ".PREFIX."_pm WHERE id='".core::clrtxt($_GET['id'])."' AND message_to='{$_SESSION['mylogin']}'",true);
			$num = @mysql_num_rows($query);
			if ($num == 1){
			    db::query("DELETE FROM ".PREFIX."_pm WHERE id='".core::clrtxt($_GET['id'])."' AND message_to='{$_SESSION['mylogin']}'",true);
			    $this->ondelit(); // Action on delit
				return error_info($lang['pm_onemess_deleted'],'error');
			} else {
			    return error_info($lang_err['pm_no_such_message'],'error');
			}
		} else {
		    core::redirect('/index.php');
		}
	}
}
?>