<?php
class nobordertmpl extends template
{
  public function templateset(){
     $template = file_get_contents($this->template_path);
	 $tags = template::$template_tags;
	 $tags_reversed = array_reverse($tags,TRUE);
	 $tag = $this->tag;
	 $uncomp_templ = $template;
	 $count=0;
	 foreach ($tags as $row => $value){
	 $count++;
	   if ($count == 1){
	     $template_return = str_replace($row, $value, $uncomp_templ);
	   } else {
	     $template_return = str_replace($row, $value, $template_return);
	   }
	 }	 
	 return $template_return;
  }
  
}
?>