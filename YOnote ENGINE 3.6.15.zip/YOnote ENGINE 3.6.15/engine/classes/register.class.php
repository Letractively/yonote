<?php
class register
{   
    public static $rows;
	
	public function onregister(){
	    ## do it
	}
	
    public function add_rows($new_rows){
	  if(register::$rows != NULL){
	    register::$rows = register::$rows+$new_rows;
	  } else {
	    register::$rows = $new_rows;
	  }
	}
	
    public function add_user(){
	    $all_rows = count(register::$rows);
		foreach (register::$rows as $key => $val){
		    $counter++;
			if ($counter == $all_rows){
			    $return .= " $key='".core::clrtxt($val)."' ";
			} else {
			    $return .= " $key='".core::clrtxt($val)."', ";
			}
		}
		if (db::query("INSERT INTO ".PREFIX."_user SET $return",false)){
		    $this->onregister();
		    return TRUE;
		} else {
		    return FALSE;
		}
	}
	
	public function apply_reg(){
	GLOBAL $validate,$config,$lang,$lang_err,$register;
	    if ($validate->standart(core::convert($_POST['login']),3,19,"!^[a-zA-Z]+[a-zA-Z0-9]+$!") != TRUE){
				    ## INVALID LOGIN ##
					return error_info($lang_err['register_login_invalid'],'error');
				} elseif ($validate->check_login(strip_tags(core::convert($_POST['login'])),strip_tags(core::convert($_POST['mail']))) != TRUE){
                    ## LOGIN IS RESERVED ##
                    return error_info($lang_err['register_login_or_email_registered'],'error');				
                } elseif ($validate->standart(core::convert($_POST['password']),6,22,"!^[a-zA-Z0-9]+$!") != TRUE){
				    ## INVALID PASSWORD ##
					return error_info($lang_err['register_password_invalid'],'error');
				} elseif (core::convert($_POST['password']) != core::convert($_POST['repass'])){
				   ## INVALID RETYPE ##
				   return error_info($lang_err['register_password_re_invalid'],'error');
				} elseif ($validate->standart(core::convert($_POST['mail']),5,50,"/[0-9a-z_]+@[0-9a-z_^\.]+\.[a-z]{2,3}/i") != TRUE){
				   ## INVALID MAIL ##
				   return error_info($lang_err['register_email_invalid'],'error');
				} elseif (core::convert($_POST['captcha']) != $_SESSION['captcha_keystring']){
				   ## INVALID CAPTCHA ##
				   return error_info($lang_err['register_captcha_invalid'],'error');
				} else {
				   ## ALL GOOD ##		   
				   
				   $rows_register = array(
				   "user_login" => strip_tags(core::convert($_POST['login'])),
				   "user_password" => md5(strip_tags(core::convert($_POST['password']))),
				   "user_mail" => strip_tags(core::convert($_POST['mail'])),
				   "user_group" => $config['standart_usergroup'],
				   "user_blocked" => '0',
				   "block_time" => '0',
				   "user_banned" => '0',
				   "user_admin" => '0',
				   "user_cant_add_comm" => '0',
				   "cant_comm_time" => '0'
				   
				   );
				   
				   if ($config['require_email_validation'] == '1'){
				   if ($config['need_account_activation'] == '1'){
				   // Need account and email validation
				   $addition_register_array = array(
					   "user_verified" => '0',
					   "user_activate" => "0"
					   );
				   $rows_register = $rows_register+$addition_register_array;
				   ######
				   } else {
				       // Need email validation ONLY
				       $addition_register_array = array(
					   "user_verified" => '0',
					   "user_activate" => "1"
					   );
					   $rows_register = $rows_register+$addition_register_array;
				   }
				   } else {
				       if ($config['need_account_activation'] == '1'){
					   // Need account validation ONLY
					   $addition_register_array = array(
					   "user_verified" => '1',
					   "user_activate" => "0"
					   );
					   $rows_register = $rows_register+$addition_register_array;
					   #####
					   } else {
					       // No any validating
				           $addition_register_array = array(
					       "user_verified" => '1',
					       "user_activate" => "1"
					       );
					       $rows_register = $rows_register+$addition_register_array;
					   }
				   }
				   
				   
				   $this->add_rows($rows_register);
				   if ($this->add_user() == TRUE){
					   if ($config['require_email_validation'] == '0'){
					     if ($config['need_account_activation'] == '0'){
					       return $this->noconfirm_reg(); // No any verification
						 } else {
						    // Need account activation ONLY
							return error_info($lang['register_need_acc_activation'],'info');
						 }
					   } else {
					       if ($config['need_account_activation'] == '1'){
						       // Need account & email activation
						       return error_info($lang['register_need_acc_and_email_activation'],'info');
						   } else {
						       // Need email activation ONLY
						       return error_info($lang['register_need_verification'],'info');
						   }
					   }
                   } else {
                       return error_info($lang_err['register_invalid'],'error');
                   }				   
				}
				
				unset($_SESSION['captcha_keystring']);
	}
	
	public function noconfirm_reg(){
    GLOBAL $lang;
        $_SESSION['mylogin']=$_POST['login'];
	    $query = db::query("SELECT * FROM ".PREFIX."_user WHERE user_login='".$_SESSION['mylogin']."'",true);
	    $row = mysql_fetch_array($query);
	    $_SESSION['myid']=$row['id'];
	    $_SESSION['mygroup']=$row['user_group'];
	    $_SESSION['logged']=md5($_SESSION['mylogin']).md5($_SESSION['myid']);
        return error_info($lang['register_success'],'info');
    }
	
	public function null_act(){
	GLOBAL $template,$config;
	if ($config['allow_ajax'] == '1'){
	    $but = "button";
	} else {
	    $but = "submit";
	}
	        $tags=array("{_CAPTCHA_}"=>"engine/service/captcha/kcaptcha/index.php?".session_name().'='.session_id(), "{_ALLOW_AJAX_}" => $but);
			$template->editpath(TEMPLATE.'/register.tpl');
			$template->settags($tags);
			$template->setbordertag('REGISTER');
			return $template->templateset();
	}
	
	public function confirm_reg(){
	GLOBAL $lang_err,$validate;
	    if($_GET['a'] != NULL && $_GET['e'] != NULL){
				    $activate_userlogin = base64_decode(core::clrtxt($_GET['a']));
					$activate_usermail = base64_decode(core::clrtxt($_GET['e']));
					if ($validate->check_login($activate_userlogin,$activate_usermail) == FALSE && $validate->verified($activate_userlogin,$activate_usermail) == FALSE){
					  if(db::query("UPDATE ".PREFIX."_user SET user_verified='1' WHERE user_login='$activate_userlogin' AND user_mail='$activate_usermail'",false)){
						$_SESSION['mylogin']=$activate_userlogin;
					    $_SESSION['myid']=login::select_my_id($_SESSION['mylogin']);
					    $_SESSION['logged']=md5($_SESSION['mylogin']).md5($_SESSION['myid']);
						return error_info($lang['register_verified'],'info');
					  } else {
					      return error_info($lang_err['register_verification_invalid'],'error');
					  }
					} else {
					    return error_info($lang_err['register_verification_failed'],'error');
					}
					
				} else {
				    return error_info($lang_err['register_verification_inv_query'],'error');
				}
	}
}

?>