<?php
class modules
{
    private $admintools;
    public function install($modname){
	    if ($this->check_ins($modname) == FALSE){
	        db::query("INSERT INTO ".PREFIX."_modules SET module_name='".core::clrtxt($modname)."', installed='1'",true);
		} else {
		    db::query("UPDATE ".PREFIX."_modules SET installed='1' WHERE module_name='".core::clrtxt($modname)."'",true);
		}
	}
	
	public function remove($modname){
	    if ($this->check_ins($modname) == TRUE){
		    db::query("UPDATE ".PREFIX."_modules SET installed='0' WHERE module_name='".core::clrtxt($modname)."'",true);
			return TRUE;
		} else {
		    return FALSE;
		}
	}
	
	public function check_ins($modname){
	    $query=db::query("SELECT * FROM ".PREFIX."_modules WHERE module_name='".core::clrtxt($modname)."'",false);
		$num=@mysql_num_rows($query);
		if ($num == 1){
		    return TRUE; // Module is currently installed
		} else {
		    return FALSE; // Module not found or more than one found
		}
	}
	
	public function load_funcs($modname){
	    $load_funcs = scandir('engine/modules/'.$modname.'/functions');
        foreach ($load_funcs as $key => $val){
	        if ($val != '.' && $val != '..'){
		        if (preg_match("!.(.mod.php)!",$val)){
			        require_once('engine/modules/'.$modname.'/functions/'.$val);
			    }
		    }
        }
	}
	
	public function load_mod_classes($modname){
    $load_classes = scandir('engine/modules/'.$modname.'/classes');
        foreach ($load_classes as $key => $val){
	        if ($val != '.' && $val != '..'){
		        if (preg_match("!.(.mod.class.php)!",$val)){
			        require_once('engine/modules/'.$modname.'/classes/'.$val);
			    }
		    }
        }
    }
	
	public function load_admin_tools($modname){
	    $this->admintools = file_get_contents("engine/modules/$modname/templates/admin.tpl");
		return $this->admintools;
	}
	
	public function load_language($modname){
	    $lang_user = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
	
	    $scan_lang = scandir('engine/modules/'.$modname.'/languages');
	    foreach ($scan_lang as $key => $val){
	      if ($val != '.' && $val != '..'){
	          $lang_scan_array[$key] = $val;
	      }
	    }
	
	    if (!in_array($lang_user, array_values($lang_scan_array))){
	        $lang = 'en';
	    } elseif (in_array($lang_user, array_values($lang_scan_array))){
	        $lang = $lang_user;
	    }
		
		
		$scan_lang = scandir('engine/modules/'.$modname.'/languages/'.$lang);
	    foreach ($scan_lang as $key => $val){
	        if ($val != '.' && $val != '..'){
		        if (preg_match("!.(.mod.lang.php)!",$val)){
			        require_once('engine/modules/'.$modname.'/languages/'.$lang.'/'.$val);
			    }
		    }
	    }
	}
}
?>