<?php
class login
{
	
	// On login action
	public function onlogin(){
	    ## do it
	}
	
	// On logout action
	public function onlogout(){
	    ## do it
	}
	
	
    public function __construct(){
	GLOBAL $template;
	    $template->add_tags(array("{_LOGIN_}" => $this->show_loginbar()));
	}
	
    public function log_in_valid($username,$password){
	    $query = db::query("SELECT * FROM ".PREFIX."_user WHERE user_login='".core::clrtxt($username)."' AND user_password='".core::clrtxt($password)."'",false);
		$num = mysql_num_rows($query);
		if ($num == 1){ return TRUE; } else { return FALSE;}
	}
	
	public function show_loginbar(){
	GLOBAL $template;
	    $template->editpath(TEMPLATE.'/login.tpl');
		if (is_logged() == TRUE){
		    $template->setbordertag('MY_PROFILE');
		} else {
		    $template->setbordertag('LOGIN');
		}
	    
		$template->settags(array(""=>""));
		return $template->templateset();
	}
	
	public function login(){
	GLOBAL $db,$user_cfg,$config,$lang_err;
	    if (is_logged() == FALSE){
		  if (@$_POST['submit']){
		    if ($this->log_in_valid(strip_tags($_POST['login']), md5(strip_tags($_POST['password'])))){
			  if ($config['need_account_activation'] == '1' && $user_cfg['user_verified'] == '1'){
			    return error_info($lang_err['login_need_verif'],'error');
			  } else {
			  
			  $this->onlogin(); // Login action
			  
				   $login = strip_tags($_POST['login']);
				    $password = md5(strip_tags($_POST['password']));
                $query = db::query("SELECT * FROM ".PREFIX."_user WHERE user_login='".core::clrtxt($login)."' AND user_password='".core::clrtxt($password)."'",false);
				$row = mysql_fetch_array($query);
				$myid = $row['id'];
				$mygroup = $row['user_group'];
				
				$_SESSION['logged'] = md5($login).md5($myid);
				$_SESSION['myid']=$myid;
				$_SESSION['mylogin']=$login;
				$_SESSION['mygroup']=$mygroup;
				
				core::redirect('/index.php');
			}
			} else {
			    core::redirect('/index.php');
			}
		  } else {
		      core::redirect('/index.php');
		  }
		} else {
		    core::redirect('/index.php');
		}
	}
	
	public function logout(){
	if (is_logged() == TRUE){
	
	$this->onlogout(); // On logout action
	
	    unset($_SESSION['logged']);
		unset($_SESSION['mylogin']);
		unset($_SESSION['myid']);
		unset($_SESSION['mygroup']);
		
		core::redirect('/index.php');
	} else {
	    core::redirect('/index.php');
	}
	}
}
?>