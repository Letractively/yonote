<?php
class stats
{
    public static $new_field = array(); // Addition return result
	
	public function add_field($add_filed){
	    if (stats::$new_field == NULL){
		    stats::$new_field = $add_filed;
		} else {
		    stats::$new_field = stats::$new_field+$add_field;
		}
	}
	
    public function show(){
	GLOBAL $noborder_template,$config,$lang_err;
	    if ($config['allow_stats'] == '1'){
		
		// Zeroing counters
		$all_news=0;
		$moder_need_news=0;
		$all_users=0;
		$user_need_moder_activation=0;
		$user_need_email_verf=0;
		$user_banned=0;
		$users_blocked=0;
		
		$query_news = db::query("SELECT * FROM ".PREFIX."_news",true);
		while ($row_news = mysql_fetch_array($query_news)){
			// All news counter
			$all_news++;
			// News need moderation counter
			if ($row_news['verified'] == '0'){
			    $moder_need_news++;
			}
		}
		
		$query_users = db::query("SELECT * FROM ".PREFIX."_user",true);
		while ($row_users = @mysql_fetch_array($query_users)){
		    // All users counter
			$all_users++;
			// Users need moder activation
			if ($row_users['user_activate'] == '0'){
			    $user_need_moder_activation++;
			}
			// Users need email verification
			if ($row_users['user_verified'] == '0'){
			    $user_need_email_verf++;
			}
			// Banned users
			if ($row_users['user_banned'] == '1'){
			    $user_banned++;
			}
			// Blocked users
			if ($row_users['user_blocked'] == '1'){
			    $users_blocked++;
			}
		}
		
		$tags = array(
		    "{_ALLNEWS_}" => $all_news,
			"{_MODERNEWS_}" => $moder_need_news,
			"{_ALLUSERS_}" => $all_users,
			"{_USERSMODER_}" => $user_need_moder_activation,
			"{_USERSEMAIL_}" => $user_need_email_verf,
			"{_USERSBANNED_}" => $user_banned,
			"{_USERSBLOCKED_}" => $users_blocked
		);
		
		if (stats::$new_field != NULL){
		    $tags = $tags+stats::$new_field;
		}
		
		    $noborder_template->editpath(TEMPLATE.'/stats.tpl');
			$noborder_template->add_tags($tags);
			return $noborder_template->templateset();
		} else {
		    return error_info($lang_err['stats_not_allowed'],'error');
		}
	}
}
?>