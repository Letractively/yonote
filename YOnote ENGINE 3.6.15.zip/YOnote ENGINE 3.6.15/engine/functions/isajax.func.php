<?php
    function is_ajax(){
	GLOBAL $config;
	    if(isset($_POST['ajax']) && $_POST['ajax'] == '1' && isset($_POST['ajaxcode']) && $_POST['ajaxcode'] == $config['ajax_code']){
		    return TRUE;
		} else {
		    return FALSE;
		}
	}
?>