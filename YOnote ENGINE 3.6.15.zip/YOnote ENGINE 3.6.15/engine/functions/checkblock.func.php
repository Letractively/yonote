<?php
function check_block(){
GLOBAL $lang_err,$group_cfg,$user_cfg;
$time = $user_cfg['block_time'];
$time_group = $group_cfg['block_time'];
    if (isset($_SESSION['logged']) && isset($_SESSION['mylogin']) && isset($_SESSION['myid']) && ($_SESSION['logged']==md5($_SESSION['mylogin']).md5($_SESSION['myid']))){
		if ($user_cfg['user_blocked'] == '1' && $time > time()){
		    die($lang_err['user_blocked'].date("d.m.Y | H:i:s",$time));
		} elseif ($user_cfg['user_blocked'] == 1 && $user_cfg['block_time'] < time()){
		    db::query("UPDATE ".PREFIX."_user SET user_blocked='0' WHERE id='".$_SESSION['myid']."'",false);
		}
	}
	
	if ($group_cfg['is_blocked'] == '1' && $group_cfg['block_time'] > time()){
		    die($lang_err['group_blocked'].date("d.m.Y | H:i:s",$time_group));
	} elseif ($group_cfg['is_blocked'] == '1' && $group_cfg['block_time'] < time()){
	    db::query("UPDATE ".PREFIX."_usergroup SET is_blocked='0' WHERE category_name='".$_SESSION['mygroup']."'",false);
	}

	if ($user_cfg['user_banned'] == '1'){
	    die($lang_err['user_banned']);
	}
	
	if ($group_cfg['is_banned'] == '1'){
	    die($lang_err['group_banned']);
	}
}
?>