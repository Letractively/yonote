<?php
// Setup database prefix
function load_mysql_def(){
    define(PREFIX,'yonote',true);
    define(DBUSER,'user',true);
    define(DBPASS,'111111',true);
    define(DBHOST,'localhost',true);
    define(DBNAME,'mydb',true);
}

?>