<?php
    function load_module(){
	GLOBAL $lang_err;
	    $query = db::query("SELECT * FROM ".PREFIX."_modules WHERE installed='1'",true);
		while ($row = @mysql_fetch_array($query)){
		    if (file_exists("engine/modules/{$row['module_name']}/functions/{$row['module_name']}.main.php")){
	            require_once('engine/modules/'.$row['module_name'].'/functions/'.$row['module_name'].'.main.php');
		    } else {
		        die( show_mess($lang_err['module_not_found'].$row['module_name']) );
		    }
		}
	}
?>