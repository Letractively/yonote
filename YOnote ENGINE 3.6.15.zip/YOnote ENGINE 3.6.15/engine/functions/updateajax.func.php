<?php
    function update_ajax(){
	GLOBAL $config;
	$time = time()+86400;
	$gen = md5(rand(0,999));
	if ($config['allow_ajax'] == '1'){
	    if ($config['ajax_time'] < time() || $config['ajax_time'] == NULL){
	        db::query("UPDATE ".PREFIX."_config SET ajax_time='$time', ajax_code='$gen'",true);
	    }
	}
	
	}
?>