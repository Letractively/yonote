<?php
function loadgroup(){
GLOBAL $group_cfg;
    if (isset($_SESSION['mygroup']) && $_SESSION['mygroup'] != NULL && is_logged() == TRUE){
	    $group = $_SESSION['mygroup'];
	} else {
	    $_SESSION['mygroup'] = 'guest';
	    $group = 'guest';
	}
	$query = db::query("SELECT * FROM ".PREFIX."_usergroup WHERE category_name='$group'",false);
	$row = @mysql_fetch_array($query);
	$num = @mysql_num_rows($query);
	if ($num > 0){
	    $group_cfg=$row;
	    return $row;
	} else {
	    die('<h1>Usergroup error.</h1><p>Maybe "guest" usergroup is not specified.');
	}
}
?>