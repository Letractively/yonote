<?php
function load_reserved_pages(){
GLOBAL $reserve_page;
    $scan = scandir('engine/service/pages');
	foreach ($scan as $key => $val){
	    if ($val != '.' && $val != '..'){
		    if (preg_match("!.(.pages.yep)!",$val)){
			    $reserve_page[$key]=str_replace(".pages.yep","",$val);
			}
		}
	}
}

function error_info($info_error,$type){
    $get_page_error = new template;
    $get_page_error->editpath(TEMPLATE.'/errors_info.tpl');
	if ($type == 'error'){
	    $get_page_error->setbordertag('ERROR');
	} elseif ($type == 'info'){
	    $get_page_error->setbordertag('INFO');
	} else {
	    die('Unregistered output type. '.(__FILE__).' '.(__LINE__));
	}
	$tags = array('{_CONTENT_}' => $info_error);
	$get_page_error->settags($tags);
	return $get_page_error->templateset();
}

function check_page(){
GLOBAL $lang_err,$template;
$flag=FALSE;
GLOBAL $reserve_page;
    foreach ($reserve_page as $key => $val){
	    if (PAGE == $val || PAGE == NULL){
		    $flag=TRUE;
		}
	}
	if ($flag == FALSE){
	   $tags_test = array(
	      "{_CONTENT_}" =>  error_info($lang_err['page_not_found'],'error')
	   );
		template::add_tags($tags_test);
	}
}
?>