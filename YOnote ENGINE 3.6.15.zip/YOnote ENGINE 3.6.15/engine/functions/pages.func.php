<?php
session_start();
    function returnpage(){
	GLOBAL $news,$config,$custom,$template,$lang_err,$validate,$register,$lang;
	GLOBAL $addnews,$comments,$login,$profile,$pm,$stats,$cats,$sitemap;
	
	
	if ($config['sort_news_by'] == 'id'){
	   $sort_by = "id";
	} elseif ($config['sort_news_by'] == 'date'){
	   $sort_by = "news_post_date"; 
	}
	
	if ($config['sort_type'] == 'ascending'){
	    $sort_type = null;
	} elseif ($config['sort_type'] == 'descending'){
	    $sort_type = "DESC";
	}
	
	    // PAGE IS NULL
	    if (PAGE == NULL){
		title::set_title($lang['pagename_main']);
		    if ($config['show_on_main'] == '0'){
		        return $news->show('short',TRUE,null,"WHERE news_hidden='0' ORDER BY $sort_by $sort_type");
			} elseif ($config['show_on_main'] == '1'){
			    $page = $_GET['p'];
				if ($page == null){
				    $page = 0;
				}
			    return $news->show('short',TRUE,null,"WHERE news_hidden='0' ORDER BY $sort_by $sort_type LIMIT ".($page*$config['news_on_page']).",".$config['news_on_page']."");
			} elseif ($config['show_on_main'] == '2'){
			    return $news->show('short',TRUE,null,"WHERE news_hidden='0' ORDER BY $sort_by $sort_type LIMIT 0,".$config['last_news_on_page']."");
			} elseif ($config['show_on_main'] == '3'){
			    return custom_page_db($config['custom_pagename']);
			} elseif ($config['show_on_main'] == '4'){
                $tags=array(""=>"");
			    $template->editpath(TEMPLATE.'/custom.tpl');
				$template->settags($tags);
				$template->setbordertag($config['custom_tpl_tag']);
				return $template->templateset();
			}
		} elseif (PAGE == 'news'){
		    if ($_GET['act'] == 'more'){
			    template::add_tags(array("{_AJAX_}" => ajax_addcomment()));
			    if (news_check() == TRUE){
				    if ($_GET['subact'] == 'allcomments'){
					    return $comments->news_all_comments();
					} else {
					    $comments->registry_comments();
				        return $news->show('full',FALSE,$_GET['id'],"WHERE news_hidden='0' LIMIT 0,1");
					}
				} else {
				    return error_info($lang_err['news_not_found'],'error');
				}
			} elseif ($_GET['act'] == 'addcomment'){
			title::set_title($lang['pagename_delcomm']);
			    if (@$_POST['submit']){
				    return $comments->check_comment($_POST['comment']);
				} else {
				    core::redirect("./index.php");
				}
			} elseif ($_GET['act'] == 'removecomments'){
			title::set_title($lang['pagename_delcomm']);
			    if (is_logged()==TRUE && $_GET['id'] != NULL && $_GET['verf'] != NULL){
				    return $comments->delete_comment();
				} else {
				    core::redirect("./index.php");
				}
			} elseif ($_GET['act'] == NULL){
			title::set_title($lang['pagename_news']);
			    $page = $_GET['p'];
				if ($page == null){
				    $page = 0;
				}
			    return $news->show('short',TRUE,null,"WHERE news_hidden='0' ORDER BY $sort_by $sort_type LIMIT ".($page*$config['news_on_page']).",".$config['news_on_page']."");
			} elseif ($_GET['act'] == 'editcomments'){
			title::set_title($lang['pagename_editcomm']);
			template::add_tags(array("{_AJAX_}" => ajax_editcomment()));
			   if ($_GET['subact'] == NULL){
			       return $comments->edit_comment();
			   } elseif ($_GET['subact'] == 'submit') {
			       if (@$_POST['submit']){
			           return $comments->update_comment();
				   } else {
				       core::redirect("./index.php");
				   }
			   }
			} elseif ($_GET['act'] == 'add'){
			title::set_title($lang['pagename_addnews']);
			    if ($_GET['subact'] == 'submit'){
				    if (@$_POST['submit']){
					    ## SUBMIT ##
						return $addnews->add_news();
					} else {
					    core::redirect("./index.php");
					}
				} else {
			        return $addnews->addnews_form();
				}
			}
		} elseif (PAGE == 'register'){
		title::set_title($lang['pagename_register']);
		  if (is_logged() == TRUE){
		      core::redirect("./index.php");
		  } else {
		    template::add_tags(array("{_AJAX_}" => ajax_register()));
		    if ($_GET['act'] == NULL){
		        return $register->null_act();
			} elseif ($_GET['act'] == 'apply'){
			    return $register->apply_reg();
			} elseif ($_GET['act'] == 'confirm'){
			    return $register->confirm_reg();
			}
		  }
		} elseif (PAGE == 'login'){
		    return $login->login();
		} elseif (PAGE == 'logout'){
		    return $login->logout();
		} elseif (PAGE == 'user'){
		    title::set_title($lang['pagename_profile']);
		    if ($_GET['act'] == 'editprofile'){
			    template::add_tags(array("{_AJAX_}" => ajax_editprofile()));
			    if ($_GET['subact'] == NULL){
			        return $profile->edit();
				} elseif ($_GET['subact'] == 'changepass'){
				    return $profile->changepassword();
				} elseif ($_GET['subact'] == 'submit'){
				    return $profile->update();
				} elseif ($_GET['subact'] == 'photo'){
				    return $profile->photo();
				}
			} else {
		        return $profile->ismyprofile();
			}
		} elseif (PAGE == 'pm'){
		    title::set_title($lang['pagename_pm']);
		    if ($_GET['act'] == NULL){
		        return $pm->pm_main();
			} elseif ($_GET['act'] == 'read'){
			    template::add_tags(array("{_AJAX_}" => ajax_pmread()));
			    return $pm->read();
			} elseif ($_GET['act'] == 'new'){
			    template::add_tags(array("{_AJAX_}" => ajax_pmnew()));
			    if ($_GET['subact'] == NULL){
			        return $pm->add();
				} elseif ($_GET['subact'] == 'submit'){
				    return $pm->submit();
				}
			} elseif ($_GET['act'] == 'pmact'){
			    return $pm->pm_action();
			} elseif ($_GET['act'] == 'del'){
			    return $pm->del_it();
			}
		} elseif (PAGE == 'stats'){
		    title::set_title($lang['pagename_stats']);
		    return $stats->show();
		} elseif (PAGE == 'custom'){
		    return $custom->custom_db($_GET['name']);
		} elseif (PAGE == 'cats'){
		title::set_title($lang['pagename_cats']);
		    if ($_GET['catid'] == NULL){
		        return $cats->return_all_cats();
			} else {
			    return $cats->showcatnews();
			}
		} elseif (PAGE == 'sitemap'){
		    template::add_tags(array("{_AJAX_}" => ajax_sitemap()));
			title::set_title($lang['pagename_sitemap']);
		    return $sitemap->mainsitemap();
		}
		
	}
?>