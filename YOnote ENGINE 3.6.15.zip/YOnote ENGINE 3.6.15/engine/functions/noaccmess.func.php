<?php
    function show_mess($message){
	GLOBAL $noborder_template;
	$noborder_template->editpath(TEMPLATE.'/noaccmess.tpl');
	$tags = array("{_MESSAGE_}"=>$message);
	        $noborder_template->add_tags($tags);
	        return $noborder_template->templateset();
	}
?>