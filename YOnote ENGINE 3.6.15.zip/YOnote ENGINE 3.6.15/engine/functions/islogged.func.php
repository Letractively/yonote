<?php
function is_logged(){
    if (isset($_SESSION['mylogin']) && isset($_SESSION['logged']) && isset($_SESSION['myid']) && $_SESSION['logged']==md5($_SESSION['mylogin']).md5($_SESSION['myid'])){
	    return TRUE;
	} else {
	    return FALSE;
	}
}
?>