<?php
    function load_modules(){
	    $query=db::query("SELECT * FROM ".PREFIX."_modules WHERE installed='1'",true);
		while ($row=mysql_fetch_array($query)){
		    return load_module($row['module_name']);
		}
	}
?>