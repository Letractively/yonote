<?php
function lngforclasses($key,$type){
GLOBAL $lang,$lang_err;
if ($type == 'lang'){
    $return = $lang;
} elseif ($type == 'lang_err'){
    $return = $lang_err;
}
return $return[$key];
}
?>