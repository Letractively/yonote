<?php
function ajax_action_validateregister(){
    GLOBAL $validate,$lang_err,$lang,$config,$register;
	            if ($validate->standart(core::convert($_POST['login']),3,19,"!^[a-zA-Z]+[a-zA-Z0-9]+$!") != TRUE){
				    ## INVALID LOGIN ##
					echo '0'; // register login invalid
				} elseif ($validate->check_login(strip_tags(core::convert($_POST['login'])),strip_tags(core::convert($_POST['mail']))) != TRUE){
                    ## LOGIN IS RESERVED ##
                    echo '1';	// login or email registered			
                } elseif ($validate->standart(core::convert($_POST['password']),6,22,"!^[a-zA-Z0-9]+$!") != TRUE){
				    ## INVALID PASSWORD ##
					echo '2'; // password invalid
				} elseif (core::convert($_POST['password']) != core::convert($_POST['repass'])){
				   ## INVALID RETYPE ##
				   echo '3'; // password confirm invalid
				} elseif ($validate->standart(core::convert($_POST['mail']),5,50,"/[0-9a-z_]+@[0-9a-z_^\.]+\.[a-z]{2,3}/i") != TRUE){
				   ## INVALID MAIL ##
				   echo '4'; // email invalid
				} elseif (core::convert($_POST['captcha']) != $_SESSION['captcha_keystring']){
				   ## INVALID CAPTCHA ##
				   echo '5'; // Captcha invalid
				} else {
				   if ($config['require_email_validation'] == '1'){
				       if ($config['need_account_activation'] == '1'){
                           echo '8'; // Need email and account activation
					   } else {
					       echo '7'; // Need email activation ONLY
					   }
                   } else {
				       if ($config['need_account_activation'] == '1'){
                           echo '9'; // Need account activation ONLY
					   } else {
                           echo '6'; // Don't need any activations
					   }
                   }
                   $register->apply_reg();				   
				}
				
}

function ajax_action_addcomm(){
GLOBAL $validate,$lang_err,$lang,$user_cfg,$group_cfg,$config,$comments;
$message = core::convert($_POST['message']);
if (is_logged() == TRUE && $user_cfg['user_cant_add_comm'] != '1' && $group_cfg['can_add_coments'] == '1'){
    if ($validate->standart(strip_tags($message),3,500,"/.?/i") != TRUE){
	    ## INVALID COMMENT ##
		echo '0';
	} else {
	    ## ADD COMMENT ##
		if ($config['comments_shoud_moderate'] == '0'){
		    $comments->check_comment(strip_tags($message));
	        echo '1';
		} else {
		    $comments->check_comment(strip_tags($message));
		    echo '6';
		}
	}
} elseif (is_logged() == FALSE && $group_cfg['can_add_coments'] == '1' && $config['unreg_can_add_comm'] == '1'){
    if ($validate->standart(strip_tags($message),3,500,"/.?/i") != TRUE){
	    ## INVALID COMMENT ##
		echo '2';
	} elseif ($_POST['captcha'] != $_SESSION['captcha_keystring']) {
	    ## INVALID CAPTCHA COMMENT ##
	    echo '3';
	} else {
	    ## ADD COMMENT ##
		if ($config['comments_shoud_moderate'] == '0'){
		    $comments->check_comment(strip_tags($message));
		    echo '4';
		} else {
		    $comments->check_comment(strip_tags($message));
		    echo '6';
		}
	}
} else {
    echo '5';
}

}
?>