<?php
function load_user_conf(){
GLOBAL $user_cfg;
    if (isset($_SESSION['logged']) && isset($_SESSION['mylogin']) && isset($_SESSION['myid']) && (is_logged()==TRUE)){
        $query=db::query("SELECT * FROM ".PREFIX."_user WHERE id='".$_SESSION['myid']."'",false);
		$row = mysql_fetch_array($query);
		$user_cfg = $row;
		return $row;
    }
}

?>