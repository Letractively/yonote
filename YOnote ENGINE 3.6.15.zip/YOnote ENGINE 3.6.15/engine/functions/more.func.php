<?php
function news_check(){
    $query = db::query("SELECT * FROM ".PREFIX."_news WHERE id='".core::clrtxt($_GET['id'])."' LIMIT 0,1",true);
	$num = @mysql_num_rows($query);
	if ($num == 1){
        return TRUE;
	} else {
	    return FALSE;
	}
}
?>