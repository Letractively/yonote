<?php
header("Content-Type: text/html; charset=cp1251");
/* YOnote ENGINE installation */
define (THIS_DIR,dirname(__FILE__),TRUE);
define (YONOTE_ENGINE, '', TRUE);

if (file_exists(THIS_DIR . '/../engine/functions/mysql.func.php')){
    echo "<meta http-equiv='Refresh' content='0; ../index.php'></meta>";
} else {

require_once(THIS_DIR . '/config.php');

$main_tmpl = file_get_contents(THIS_DIR . '/template/main.tpl');
echo $main_tmpl;
}


?>