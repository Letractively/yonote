<?php
if (!defined("YONOTE_ENGINE")){
    die('hacking attempt!');
}


?>