<?php
header("Content-Type: text/html; charset=cp1251");
/* YOnote ENGINE installation */
define (THIS_DIR,dirname(__FILE__),TRUE);
define (YONOTE_ENGINE, '', TRUE);

if (!@$_POST['submit']){
    echo "<meta http-equiv='Refresh' content='0; /installation/index.php'></meta>";
}

require_once(THIS_DIR . '/config.php');

function check_user_lang(){
    $lang_user = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
	
	$scan_lang = scandir(THIS_DIR . '/lang');
	foreach ($scan_lang as $key => $val){
	  if ($val != '.' && $val != '..'){
	      $lang_scan_array[$key] = $val;
	  }
	}
	
	if (!in_array($lang_user, array_values($lang_scan_array))){
	    $lang = 'en';
	} elseif (in_array($lang_user, array_values($lang_scan_array))){
	    $lang = $lang_user;
	}
	
	return $lang;
}

function load_user_lang(){
    $scan_lang = scandir(THIS_DIR . '/lang/'.check_user_lang());
	foreach ($scan_lang as $key => $val){
	    if ($val != '.' && $val != '..'){
		    if (preg_match("!.(.lang.php)!",$val)){
			    require_once(THIS_DIR . '/lang/'.check_user_lang().'/'.$val);
			}
		}
	}
	
}

load_user_lang();

function info_error($txt){
    $file = file_get_contents(THIS_DIR . '/template/process.tpl');
	$file = str_replace("{_CONTENT_}",$txt,$file);
	return $file;
}

function clear($text){
    return strip_tags($text);
}

function fullclear($text){
    return mysql_real_escape_string(strip_tags($text));
}

function validate($input,$min,$max,$pattern){
    if (strlen(fullclear($input)) < $min || strlen(fullclear($input)) > $max || !preg_match("$pattern",fullclear($input))){
	    return FALSE;
	} else {
	    return TRUE;
	}
}

function mysql_make_connection($host,$user,$password,$db){
    @mysql_connect($host,$user,$password);
	@mysql_select_db($db);
}

function create_structure($prefix){
    // Create table *_user
mysql_query("
CREATE TABLE ".$prefix."_user(
id INT PRIMARY KEY AUTO_INCREMENT,
user_login VARCHAR(20),
user_password VARCHAR(150),
user_mail VARCHAR(100),
user_activate BOOLEAN,
user_blocked BOOLEAN,
block_time VARCHAR(30),
user_banned BOOLEAN,
user_admin BOOLEAN,
user_name VARCHAR(50),
user_location VARCHAR(50),
user_about VARCHAR(250),
user_signature VARCHAR(100),
user_photo VARCHAR(150),
user_group VARCHAR(50),
user_verified BOOLEAN,
user_cant_add_comm BOOLEAN,
cant_comm_time VARCHAR(30)
) ENGINE=MyISAM /*!40101 DEFAULT CHARACTER SET cp1251 COLLATE cp1251_general_ci */;
");

// Create table *_news
mysql_query("
CREATE TABLE ".$prefix."_news(
id INT PRIMARY KEY AUTO_INCREMENT,
news_title VARCHAR(100),
news_short VARCHAR(1000),
news_full VARCHAR(5000),
news_author VARCHAR(20),
news_author_id INT,
news_post_date INT,
news_allow_unreg BOOLEAN,
news_allow_comment BOOLEAN,
news_category VARCHAR(100),
news_category_id INT,
news_rating INT,
verified BOOLEAN,
news_hidden BOOLEAN
) ENGINE=MyISAM /*!40101 DEFAULT CHARACTER SET cp1251 COLLATE cp1251_general_ci */;
");

// Create table *_news_cats
mysql_query("
CREATE TABLE ".$prefix."_news_cats(
id INT PRIMARY KEY AUTO_INCREMENT,
cat_name VARCHAR(30),
cat_desc VARCHAR(100)
) ENGINE=MyISAM /*!40101 DEFAULT CHARACTER SET cp1251 COLLATE cp1251_general_ci */;
");

// Create table *_config
mysql_query("
CREATE TABLE ".$prefix."_config(
id INT PRIMARY KEY AUTO_INCREMENT,
require_email_validation BOOLEAN,
show_on_main VARCHAR(50),
site_template VARCHAR(30),
site_name VARCHAR(100),
sort_news_by VARCHAR(50),
sort_type VARCHAR(50),
news_on_page INT,
last_news_on_page INT,
custom_pagename VARCHAR(50),
custom_tpl_tag VARCHAR(50),
need_account_activation BOOLEAN,
standart_usergroup VARCHAR(50),
unreg_can_add_comm BOOLEAN,
comments_shoud_moderate BOOLEAN,
comm_on_news INT,
sort_comments_by VARCHAR(50),
comments_sort_type VARCHAR(50),
description VARCHAR(200),
keywords VARCHAR(260),
allow_ajax BOOLEAN,
ajax_time VARCHAR(30),
ajax_code VARCHAR(50),
news_cat_sort_type VARCHAR(30),
news_cat_sort_by VARCHAR(30),
allow_news_unreg_default BOOLEAN,
allow_news_comments_default BOOLEAN,
news_need_verification BOOLEAN,
userphoto_max_w INT,
userphoto_max_h INT,
userphoto_max_size INT,
site_url VARCHAR(50)
) ENGINE=MyISAM /*!40101 DEFAULT CHARACTER SET cp1251 COLLATE cp1251_general_ci */;
");

// Create table *_pages
mysql_query("
CREATE TABLE ".$prefix."_pages(
id INT PRIMARY KEY AUTO_INCREMENT,
page_name VARCHAR(50),
page_title VARCHAR(50),
page_content VARCHAR(5000),
page_hidden BOOLEAN
) ENGINE=MyISAM /*!40101 DEFAULT CHARACTER SET cp1251 COLLATE cp1251_general_ci */;
");

// Create table *_usergroup
mysql_query("
CREATE TABLE ".$prefix."_usergroup(
id INT PRIMARY KEY AUTO_INCREMENT,
category_name VARCHAR(50),
category_description VARCHAR(100),
can_add_news BOOLEAN,
can_add_coments BOOLEAN,
can_delete_own_comments BOOLEAN,
can_delete_all_comments BOOLEAN,
can_edit_own_comments BOOLEAN,
can_edit_all_comments BOOLEAN,
is_blocked BOOLEAN,
block_time VARCHAR(30),
is_banned BOOLEAN,
is_admin BOOLEAN,
can_use_pm BOOLEAN,
pm_max_size INT
) ENGINE=MyISAM /*!40101 DEFAULT CHARACTER SET cp1251 COLLATE cp1251_general_ci */;
");

// Create table *_comments
mysql_query("
CREATE TABLE ".$prefix."_comments(
id INT PRIMARY KEY AUTO_INCREMENT,
comment_author VARCHAR(20),
comment_author_id INT,
comment_content VARCHAR(500),
comment_date VARCHAR(30),
comment_verif BOOLEAN,
for_news_id INT
) ENGINE=MyISAM /*!40101 DEFAULT CHARACTER SET cp1251 COLLATE cp1251_general_ci */;
");

// Create table *_pm
mysql_query("
CREATE TABLE ".$prefix."_pm(
id INT PRIMARY KEY AUTO_INCREMENT,
message_type VARCHAR(30),
message_from VARCHAR(20),
message_from_id INT,
message_title VARCHAR(30),
message_to VARCHAR(20),
message_date INT,
message_read BOOLEAN,
message VARCHAR(500)
) ENGINE=MyISAM /*!40101 DEFAULT CHARACTER SET cp1251 COLLATE cp1251_general_ci */;
");

// Create table *_modules
mysql_query("
CREATE TABLE ".$prefix."_modules(
id INT PRIMARY KEY AUTO_INCREMENT,
module_name VARCHAR(30),
installed BOOLEAN
) ENGINE=MyISAM /*!40101 DEFAULT CHARACTER SET cp1251 COLLATE cp1251_general_ci */;
");
}

function insert_admin($prefix,$user,$password){
    mysql_query("INSERT INTO ".$prefix."_user values('1','$user','$password','','1','0','','0','1','','','','','','admin','1','0','')");
}

function set_configuration($prefix,$user){
    mysql_query("INSERT INTO ".$prefix."_config values('1','1','1','default','YOnote ENGINE','id','descending','5','5','','','0','user','1','1','10','id','descending','about your site','yonote,engine,cms,free,open-source','1','','','descending','id','1','1','1','100','100','102400','".fullclear($_POST['site_url'])."')");
	mysql_query("INSERT INTO ".$prefix."_news_cats values('1','news','�������')");
	mysql_query("INSERT INTO ".$prefix."_news values('1','��������� �������� �������','Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','$user','1','".time()."','1','1','�������','1','','1','0')");
	mysql_query("INSERT INTO ".$prefix."_pages values('1','test','�������� ��������','Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','0')");
    
	// Create main usergroups
	mysql_query("INSERT INTO ".$prefix."_usergroup values('1','user','������������','1','1','0','0','0','0','0','','0','0','1','50')");
	mysql_query("INSERT INTO ".$prefix."_usergroup values('2','admin','��������������','1','1','1','1','1','1','0','','0','1','1','50')");
	mysql_query("INSERT INTO ".$prefix."_usergroup values('3','guest','�����','0','1','0','0','0','0','0','','0','0','0','0')");
	mysql_query("INSERT INTO ".$prefix."_usergroup values('4','banned','����������','0','0','0','0','0','0','0','','1','0','0','0')");
	
	// Create test comment
	mysql_query("INSERT INTO ".$prefix."_comments values('1','$user','1','�������� �����������.','".time()."','1','1')");
	
	// Create test pm
	mysql_query("INSERT INTO ".$prefix."_comments values('1','inbox','$user','1','���������� ���!','$user','".time()."','0','�������, ��� ������� YOnote ENGINE!')");
	
} 

if (@mysql_connect(clear($_POST['db_host']),clear($_POST['db_user']),clear($_POST['db_password']))){
    if (@mysql_select_db(clear($_POST['db_name']))){
	    if (!validate(fullclear($_POST['admin_login']),3,19,"!^[a-zA-Z]+[a-zA-Z0-9]+$!")){
		    echo info_error($lang['admin_login_invalid']);
		} elseif(!validate(fullclear($_POST['admin_password']),6,22,"!^[a-zA-Z0-9]+$!")){
		    echo info_error($lang['admin_password_invalid']);
		} elseif(fullclear($_POST['re_password']) != fullclear($_POST['admin_password'])){
		    echo info_error($lang['admin_passwords_not_ident']);
		} else {
$mysql_code = "<?php
// Setup database prefix
function load_mysql_def(){
    define(PREFIX,'".fullclear($_POST['db_prefix'])."',true);
    define(DBUSER,'".fullclear($_POST['db_user'])."',true);
    define(DBPASS,'".fullclear($_POST['db_password'])."',true);
    define(DBHOST,'".fullclear($_POST['db_host'])."',true);
    define(DBNAME,'".fullclear($_POST['db_name'])."',true);
}

?>";
            $fp = @fopen(THIS_DIR . '/../engine/functions/mysql.func.php', "w");
			if (@fwrite($fp, $mysql_code)){
			    ## INSTALL ##
				
				mysql_make_connection(clear($_POST['db_host']),clear($_POST['db_user']),clear($_POST['db_password']),clear($_POST['db_name'])); // Create MySQL connection
				create_structure(fullclear($_POST['db_prefix']));
				insert_admin(fullclear($_POST['db_prefix']),fullclear($_POST['admin_login']),md5(fullclear($_POST['admin_password'])));
				set_configuration(fullclear($_POST['db_prefix']),fullclear($_POST['admin_login']));
				
				fclose($fp);
				echo info_error($lang['installation_complete']); 
			} else {
			    echo info_error($lang['cant_create_mysql_func']); 
			}
		}
	} else {
	    echo info_error($lang['cant_connect_to_db']);
	}
} else {
    echo info_error($lang['cant_create_mysql_connection']);
}


?>