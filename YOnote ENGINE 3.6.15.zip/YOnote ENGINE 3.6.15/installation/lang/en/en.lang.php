<?php
GLOBAL $lang;
$lang = array(

);
?>